package com.heroic;

import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;

/** The six Core Gems (original designs). Socketed into the suit chestplate. */
public final class Gems {
    public static final int COUNT = 6;
    public static final int ALL = 0b111111;
    public static final String[] NAMES = {"vigor", "rift", "mirage", "chrono", "psyche", "spirit"};
    public static final int[] COLORS = {0xA020F0, 0x2E86FF, 0xE63946, 0x2ECC71, 0xF4D03F, 0xFF8C00};

    private Gems() {}

    public static int mask(PlayerEntity p) {
        Integer m = p.getEquippedStack(EquipmentSlot.CHEST).get(ModComponents.GEMS);
        return m == null ? 0 : m;
    }

    public static int nextSelected(int mask, int current) {
        for (int i = 1; i <= COUNT; i++) {
            int g = (current + i) % COUNT;
            if ((mask >> g & 1) != 0) return g;
        }
        return current;
    }

    public static int firstSet(int mask) {
        for (int i = 0; i < COUNT; i++) if ((mask >> i & 1) != 0) return i;
        return 0;
    }
}
