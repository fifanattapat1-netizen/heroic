package com.heroic;

import com.heroic.net.HeroSyncPayload;
import com.heroic.power.Power;
import com.heroic.power.PowerRegistry;
import com.heroic.power.Powers;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public final class HeroTicker {
    private static final float REGEN = 0.3f;
    private static final float GEM_REGEN = 0.1f;
    private static final float MIN_START_ENERGY = 10f;
    private static final int GEM_ENERGY = 30;
    private static final EquipmentSlot[] SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    private HeroTicker() {}

    public static int maxEnergy(HeroDefinition d, ServerPlayerEntity p) {
        return d.maxEnergy() + GEM_ENERGY * Integer.bitCount(Gems.mask(p));
    }

    public static void tick(MinecraftServer server) {
        int now = server.getTicks();
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            PlayerHeroState st = HeroStates.get(p);
            NanoSystem.tick(p, st, now);

            HeroDefinition worn = HeroUtil.wornHero(p);
            Identifier wornId = worn == null ? null : worn.id();

            if (!Objects.equals(wornId, st.hero)) {
                deactivateAll(p, st);
                st.hero = wornId;
                boolean keep = worn != null && st.keepEnergy >= 0;
                if (worn == null) {
                    st.energy = 0;
                } else {
                    float max = maxEnergy(worn, p);
                    st.energy = keep ? Math.min(max, st.keepEnergy) : max;
                    st.keepEnergy = -1;
                }
                if (!keep) st.cooldownUntil.clear();
                st.pendingSlam = false;
                st.dirty = true;
            }

            AiSystem.tick(p, st, worn, now);

            if (worn == null) {
                if (st.dirty) {
                    sync(p, st, now);
                    st.dirty = false;
                }
                continue;
            }

            int gemMask = Gems.mask(p);
            if ((gemMask >> st.selectedGem & 1) == 0) st.selectedGem = Gems.firstSet(gemMask);
            float max = maxEnergy(worn, p);
            if (st.energy > max) st.energy = max;

            boolean drained = false;
            for (Identifier pid : new ArrayList<>(st.active)) {
                Power power = PowerRegistry.get(pid);
                if (power == null || !worn.powers().contains(pid) || st.energy < power.cost()) {
                    st.active.remove(pid);
                    if (power != null) power.deactivate(p, st);
                    st.dirty = true;
                    continue;
                }
                st.energy -= power.cost();
                drained = true;
                power.tick(p, st);
            }
            if (!drained) {
                st.energy = Math.min(max, st.energy + REGEN + GEM_REGEN * Integer.bitCount(gemMask));
            }

            // nano self-repair: the suit mends itself using energy
            if (now % 40 == 0 && st.energy >= 2) {
                for (EquipmentSlot slot : SLOTS) {
                    ItemStack s = p.getEquippedStack(slot);
                    if (s.isDamaged()) {
                        s.setDamage(s.getDamage() - 1);
                        st.energy -= 2;
                        break;
                    }
                }
            }

            if (st.pendingSlam) {
                st.slamTicks++;
                if (st.slamTicks > 3 && p.isOnGround()) {
                    st.pendingSlam = false;
                    Powers.groundSlamImpact(p);
                } else if (st.slamTicks > 200) {
                    st.pendingSlam = false;
                }
            }

            if (!st.active.isEmpty() && p.age % 3 == 0) {
                Vector3f c = Vec3d.unpackRgb(worn.color()).toVector3f();
                p.getServerWorld().spawnParticles(new DustParticleEffect(c, 1.0f),
                        p.getX(), p.getY() + 1.0, p.getZ(), 4, 0.3, 0.5, 0.3, 0.0);
            }

            if (st.dirty || p.age % 4 == 0) {
                sync(p, st, now);
                st.dirty = false;
            }
        }
    }

    public static void activate(ServerPlayerEntity p, int slot) {
        PlayerHeroState st = HeroStates.get(p);
        HeroDefinition worn = HeroUtil.wornHero(p);
        if (worn == null || slot < 0 || slot >= worn.powers().size()) return;
        Identifier pid = worn.powers().get(slot);
        Power power = PowerRegistry.get(pid);
        if (power == null) return;
        int now = p.getServer().getTicks();

        if (power.isToggle()) {
            if (st.active.contains(pid)) {
                st.active.remove(pid);
                power.deactivate(p, st);
                HeroUtil.sound(p, SoundEvents.BLOCK_BEACON_DEACTIVATE, 1.5f);
            } else if (st.energy >= MIN_START_ENERGY) {
                st.active.add(pid);
                power.activate(p, st);
                HeroUtil.sound(p, SoundEvents.BLOCK_BEACON_ACTIVATE, 1.5f);
            }
        } else {
            if (now < st.cooldownUntil.getOrDefault(pid, 0) || st.energy < power.cost()) return;
            st.energy -= power.cost();
            st.cooldownUntil.put(pid, now + power.cooldown());
            power.activate(p, st);
        }
        st.dirty = true;
    }

    public static void deactivateAll(ServerPlayerEntity p, PlayerHeroState st) {
        for (Identifier pid : new ArrayList<>(st.active)) {
            Power power = PowerRegistry.get(pid);
            if (power != null) power.deactivate(p, st);
        }
        st.active.clear();
    }

    private static void sync(ServerPlayerEntity p, PlayerHeroState st, int now) {
        HeroDefinition def = HeroManager.get(st.hero);
        int mask = 0;
        int gemInfo = 0;
        List<Integer> cds = new ArrayList<>();
        if (def != null) {
            for (int i = 0; i < def.powers().size(); i++) {
                Identifier pid = def.powers().get(i);
                if (st.active.contains(pid)) mask |= 1 << i;
                cds.add(Math.max(0, st.cooldownUntil.getOrDefault(pid, 0) - now));
            }
            int gm = Gems.mask(p);
            int gcd = Math.min(255, (Math.max(0, st.gemCooldownUntil[st.selectedGem] - now) + 19) / 20);
            gemInfo = gm | (st.selectedGem << 6) | (gcd << 9);
        }
        ServerPlayNetworking.send(p, new HeroSyncPayload(
                def == null ? HeroSyncPayload.NONE : def.id(),
                st.energy, def == null ? 0 : maxEnergy(def, p), mask, cds, gemInfo));
    }
}
