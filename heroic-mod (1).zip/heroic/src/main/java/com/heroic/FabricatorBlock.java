package com.heroic;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class FabricatorBlock extends Block {
    public static final MapCodec<FabricatorBlock> CODEC = createCodec(FabricatorBlock::new);

    /** Set by the client entrypoint so this class never touches client-only code. */
    public static Runnable openScreen = () -> {};

    public FabricatorBlock(Settings settings) {
        super(settings);
    }

    @Override
    protected MapCodec<? extends Block> getCodec() {
        return CODEC;
    }

    @Override
    protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
        if (world.isClient) openScreen.run();
        return ActionResult.SUCCESS;
    }
}
