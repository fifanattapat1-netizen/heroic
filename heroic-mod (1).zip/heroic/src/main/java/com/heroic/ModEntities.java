package com.heroic;

import com.heroic.entity.DroneEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public final class ModEntities {
    public static final EntityType<DroneEntity> DRONE = Registry.register(Registries.ENTITY_TYPE,
            HeroicMod.id("drone"),
            EntityType.Builder.create(DroneEntity::new, SpawnGroup.MISC)
                    .dimensions(0.8f, 0.6f)
                    .maxTrackingRange(8)
                    .makeFireImmune()
                    .build("drone"));

    private ModEntities() {}

    public static void init() {
        FabricDefaultAttributeRegistry.register(DRONE, DroneEntity.createDroneAttributes());
    }
}
