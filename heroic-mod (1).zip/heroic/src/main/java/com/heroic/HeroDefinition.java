package com.heroic;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.util.Identifier;

import java.util.List;

/** A hero loaded from data/<namespace>/heroes/<name>.json */
public record HeroDefinition(Identifier id, int color, List<Identifier> powers, int maxEnergy, boolean ai) {

    public static final PacketCodec<ByteBuf, HeroDefinition> PACKET_CODEC = PacketCodec.tuple(
            Identifier.PACKET_CODEC, HeroDefinition::id,
            PacketCodecs.VAR_INT, HeroDefinition::color,
            Identifier.PACKET_CODEC.collect(PacketCodecs.toList()), HeroDefinition::powers,
            PacketCodecs.VAR_INT, HeroDefinition::maxEnergy,
            PacketCodecs.BOOL, HeroDefinition::ai,
            HeroDefinition::new);

    private static final Codec<Integer> HEX_COLOR = Codec.STRING.comapFlatMap(s -> {
        try {
            String h = s.startsWith("#") ? s.substring(1) : s;
            return DataResult.success(Integer.parseInt(h, 16));
        } catch (NumberFormatException e) {
            return DataResult.error(() -> "Invalid color: " + s);
        }
    }, i -> String.format("#%06X", i & 0xFFFFFF));

    /** The JSON body (the id comes from the file path). */
    public record Data(int color, List<Identifier> powers, int maxEnergy, boolean ai) {
        public static final Codec<Data> CODEC = RecordCodecBuilder.create(i -> i.group(
                HEX_COLOR.fieldOf("color").forGetter(Data::color),
                Identifier.CODEC.listOf().optionalFieldOf("powers", List.of()).forGetter(Data::powers),
                Codec.INT.optionalFieldOf("max_energy", 100).forGetter(Data::maxEnergy),
                Codec.BOOL.optionalFieldOf("ai", false).forGetter(Data::ai)
        ).apply(i, Data::new));
    }

    public HeroDefinition(Identifier id, Data d) {
        this(id, d.color(), d.powers(), d.maxEnergy(), d.ai());
    }

    public String translationKey() {
        return "hero." + id.getNamespace() + "." + id.getPath();
    }
}
