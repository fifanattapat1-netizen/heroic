package com.heroic;

import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector3f;

/** Nanotech: the suit builds itself piece by piece out of a Nano Core, and folds back into it. */
public final class NanoSystem {
    private static final EquipmentSlot[] DEPLOY = {
            EquipmentSlot.FEET, EquipmentSlot.LEGS, EquipmentSlot.CHEST, EquipmentSlot.HEAD};
    private static final EquipmentSlot[] RETRACT = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private static final int STEP_TICKS = 3;

    private NanoSystem() {}

    private static Item pieceFor(EquipmentSlot s) {
        return switch (s) {
            case HEAD -> ModItems.HERO_HELMET;
            case CHEST -> ModItems.HERO_CHESTPLATE;
            case LEGS -> ModItems.HERO_LEGGINGS;
            default -> ModItems.HERO_BOOTS;
        };
    }

    public static ItemStack findCore(ServerPlayerEntity p) {
        for (int i = 0; i < p.getInventory().size(); i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (s.getItem() instanceof NanoCoreItem) return s;
        }
        return null;
    }

    public static void toggle(ServerPlayerEntity p, ItemStack preferred) {
        PlayerHeroState st = HeroStates.get(p);
        if (st.nanoStage != 0) return;
        ItemStack core = preferred != null ? preferred : findCore(p);
        if (core == null) {
            p.sendMessage(Text.translatable("message.heroic.nano_need_core"), true);
            return;
        }
        HeroDefinition worn = HeroUtil.wornHero(p);
        if (worn != null) {
            // retract: store the suit in the core
            core.set(ModComponents.HERO_ID, worn.id());
            core.set(ModComponents.GEMS, Gems.mask(p));
            st.keepEnergy = st.energy;
            st.nanoStage = -4;
            st.nanoNext = 0;
        } else {
            Identifier hid = core.get(ModComponents.HERO_ID);
            if (hid == null || HeroManager.get(hid) == null) {
                p.sendMessage(Text.translatable("message.heroic.nano_empty"), true);
                return;
            }
            st.nanoHero = hid;
            st.nanoGems = core.getOrDefault(ModComponents.GEMS, 0);
            st.nanoStage = 4;
            st.nanoNext = 0;
        }
    }

    public static void tick(ServerPlayerEntity p, PlayerHeroState st, int now) {
        if (st.nanoStage == 0 || now < st.nanoNext) return;
        st.nanoNext = now + STEP_TICKS;
        HeroDefinition hero = HeroManager.get(st.nanoHero);

        if (st.nanoStage > 0) {
            EquipmentSlot slot = DEPLOY[4 - st.nanoStage];
            if (hero == null) {
                st.nanoStage = 0;
                return;
            }
            ItemStack old = p.getEquippedStack(slot);
            if (!old.isEmpty()) p.getInventory().offerOrDrop(old.copy());
            ItemStack piece = HeroSuitItem.stackFor(pieceFor(slot), hero);
            if (slot == EquipmentSlot.CHEST && st.nanoGems != 0) piece.set(ModComponents.GEMS, st.nanoGems);
            p.equipStack(slot, piece);
            fx(p, slot, hero.color(), 1.0f + (4 - st.nanoStage) * 0.2f);
            st.nanoStage--;
        } else {
            EquipmentSlot slot = RETRACT[4 + st.nanoStage];
            int color = hero != null ? hero.color() : 0x66CCFF;
            ItemStack cur = p.getEquippedStack(slot);
            if (cur.getItem() instanceof HeroSuitItem) {
                Identifier id = cur.get(ModComponents.HERO_ID);
                HeroDefinition h = HeroManager.get(id);
                if (h != null) color = h.color();
                p.equipStack(slot, ItemStack.EMPTY);
            }
            fx(p, slot, color, 1.8f - (4 + st.nanoStage) * 0.2f);
            st.nanoStage++;
        }
    }

    private static void fx(ServerPlayerEntity p, EquipmentSlot slot, int color, float pitch) {
        double y = switch (slot) {
            case HEAD -> 1.7;
            case CHEST -> 1.2;
            case LEGS -> 0.7;
            default -> 0.1;
        };
        Vector3f c = Vec3d.unpackRgb(color).toVector3f();
        p.getServerWorld().spawnParticles(new DustParticleEffect(c, 1.2f),
                p.getX(), p.getY() + y, p.getZ(), 25, 0.3, 0.12, 0.3, 0.0);
        p.getServerWorld().playSound(null, p.getX(), p.getY(), p.getZ(),
                SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, SoundCategory.PLAYERS, 1.0f, pitch);
    }
}
