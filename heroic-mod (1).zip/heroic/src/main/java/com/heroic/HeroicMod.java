package com.heroic;

import com.heroic.net.ModNetworking;
import com.heroic.power.Powers;
import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HeroicMod implements ModInitializer {
    public static final String MOD_ID = "heroic";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModComponents.init();
        ModArmorMaterials.init();
        ModBlocks.init();
        ModEntities.init();
        ModItems.init();
        Powers.init();
        HeroManager.init();
        ModNetworking.init();
        ModCommands.init();
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents.END_SERVER_TICK.register(CityBuilder::tick);
        LOGGER.info("Heroic loaded");
    }
}
