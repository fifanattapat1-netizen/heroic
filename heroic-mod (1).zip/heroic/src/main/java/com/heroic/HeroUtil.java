package com.heroic;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.Optional;

public final class HeroUtil {
    private static final EquipmentSlot[] SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    private HeroUtil() {}

    /** The hero whose FULL suit (4 matching pieces) the player wears, or null. */
    public static HeroDefinition wornHero(PlayerEntity p) {
        Identifier id = null;
        for (EquipmentSlot slot : SLOTS) {
            ItemStack st = p.getEquippedStack(slot);
            if (!(st.getItem() instanceof HeroSuitItem)) return null;
            Identifier h = st.get(ModComponents.HERO_ID);
            if (h == null || (id != null && !id.equals(h))) return null;
            id = h;
        }
        return HeroManager.get(id);
    }

    public static void sound(ServerPlayerEntity p, SoundEvent s, float pitch) {
        p.getServerWorld().playSound(null, p.getX(), p.getY(), p.getZ(), s, SoundCategory.PLAYERS, 1.0f, pitch);
    }

    public static BlockHitResult traceBlocks(ServerPlayerEntity p, double dist) {
        Vec3d start = p.getEyePos();
        Vec3d end = start.add(p.getRotationVec(1.0f).multiply(dist));
        return p.getWorld().raycast(new RaycastContext(start, end,
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
    }

    public static LivingEntity traceEntity(ServerPlayerEntity p, double dist) {
        Vec3d start = p.getEyePos();
        Vec3d dir = p.getRotationVec(1.0f);
        double max = dist;
        BlockHitResult bh = traceBlocks(p, dist);
        if (bh.getType() != net.minecraft.util.hit.HitResult.Type.MISS) max = start.distanceTo(bh.getPos());
        Vec3d end = start.add(dir.multiply(max));
        Box box = p.getBoundingBox().stretch(dir.multiply(max)).expand(1.0);
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (Entity e : p.getWorld().getOtherEntities(p, box,
                en -> en instanceof LivingEntity && en.isAlive() && !en.isSpectator())) {
            Optional<Vec3d> hit = e.getBoundingBox().expand(0.3).raycast(start, end);
            if (hit.isPresent()) {
                double d = start.squaredDistanceTo(hit.get());
                if (d < bestDist) {
                    bestDist = d;
                    best = (LivingEntity) e;
                }
            }
        }
        return best;
    }

    /** True if the player wears AEGIS glasses, or a full suit whose hero has the "ai" flag. */
    public static boolean hasAi(PlayerEntity p, HeroDefinition worn) {
        if (p.getEquippedStack(EquipmentSlot.HEAD).getItem() instanceof SmartGlassesItem) return true;
        return worn != null && worn.ai();
    }
}
