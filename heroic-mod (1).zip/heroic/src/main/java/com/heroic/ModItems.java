package com.heroic;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Rarity;

import java.util.List;

public final class ModItems {
    private static final int DURABILITY = 37;

    public static final Item HERO_HELMET = suit("hero_helmet", ArmorItem.Type.HELMET);
    public static final Item HERO_CHESTPLATE = suit("hero_chestplate", ArmorItem.Type.CHESTPLATE);
    public static final Item HERO_LEGGINGS = suit("hero_leggings", ArmorItem.Type.LEGGINGS);
    public static final Item HERO_BOOTS = suit("hero_boots", ArmorItem.Type.BOOTS);

    public static final List<Item> SUIT_PIECES = List.of(HERO_HELMET, HERO_CHESTPLATE, HERO_LEGGINGS, HERO_BOOTS);

    public static final Item SMART_GLASSES = Registry.register(Registries.ITEM, HeroicMod.id("smart_glasses"),
            new SmartGlassesItem(ModArmorMaterials.GLASSES, ArmorItem.Type.HELMET,
                    new Item.Settings().maxDamage(ArmorItem.Type.HELMET.getMaxDamage(10))));

    public static final Item[] GEM_ITEMS = createGems();
    public static final Item NANO_CORE = Registry.register(Registries.ITEM, HeroicMod.id("nano_core"),
            new NanoCoreItem(new Item.Settings().maxCount(1).rarity(Rarity.RARE)));

    public static final ItemGroup HEROES_TAB = Registry.register(Registries.ITEM_GROUP, HeroicMod.id("heroes"),
            FabricItemGroup.builder()
                    .icon(() -> new ItemStack(HERO_HELMET))
                    .displayName(Text.translatable("itemGroup.heroic.heroes"))
                    .entries((ctx, entries) -> {
                        entries.add(ModBlocks.SUIT_FABRICATOR_ITEM);
                        entries.add(SMART_GLASSES);
                        entries.add(NANO_CORE);
                        for (Item g : GEM_ITEMS) entries.add(g);
                        for (HeroDefinition hero : HeroManager.all())
                            for (Item piece : SUIT_PIECES)
                                entries.add(HeroSuitItem.stackFor(piece, hero));
                    })
                    .build());

    private static Item[] createGems() {
        Item[] a = new Item[Gems.COUNT];
        for (int i = 0; i < Gems.COUNT; i++) {
            a[i] = Registry.register(Registries.ITEM, HeroicMod.id("gem_" + Gems.NAMES[i]),
                    new GemItem(new Item.Settings().maxCount(1).rarity(Rarity.EPIC), i));
        }
        return a;
    }

    private ModItems() {}

    private static Item suit(String name, ArmorItem.Type type) {
        return Registry.register(Registries.ITEM, HeroicMod.id(name),
                new HeroSuitItem(ModArmorMaterials.HERO, type,
                        new Item.Settings().maxDamage(type.getMaxDamage(DURABILITY))));
    }

    public static void init() {}
}
