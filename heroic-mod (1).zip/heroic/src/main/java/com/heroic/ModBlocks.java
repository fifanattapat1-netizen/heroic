package com.heroic;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.MapColor;
import net.minecraft.block.enums.NoteBlockInstrument;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;

public final class ModBlocks {
    public static final Block SUIT_FABRICATOR = Registry.register(Registries.BLOCK, HeroicMod.id("suit_fabricator"),
            new FabricatorBlock(AbstractBlock.Settings.create()
                    .mapColor(MapColor.IRON_GRAY)
                    .instrument(NoteBlockInstrument.IRON_XYLOPHONE)
                    .strength(3.5f)
                    .sounds(BlockSoundGroup.METAL)
                    .requiresTool()));

    public static final Item SUIT_FABRICATOR_ITEM = Registry.register(Registries.ITEM, HeroicMod.id("suit_fabricator"),
            new BlockItem(SUIT_FABRICATOR, new Item.Settings()));

    private ModBlocks() {}

    public static void init() {}
}
