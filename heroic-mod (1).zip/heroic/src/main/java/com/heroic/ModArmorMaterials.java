package com.heroic;

import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.Items;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Util;

import java.util.EnumMap;
import java.util.List;

public final class ModArmorMaterials {
    public static final RegistryEntry<ArmorMaterial> HERO = Registry.registerReference(
            Registries.ARMOR_MATERIAL, HeroicMod.id("hero"),
            new ArmorMaterial(
                    Util.make(new EnumMap<>(ArmorItem.Type.class), m -> {
                        m.put(ArmorItem.Type.BOOTS, 2);
                        m.put(ArmorItem.Type.LEGGINGS, 5);
                        m.put(ArmorItem.Type.CHESTPLATE, 6);
                        m.put(ArmorItem.Type.HELMET, 2);
                        m.put(ArmorItem.Type.BODY, 5);
                    }),
                    15,
                    SoundEvents.ITEM_ARMOR_EQUIP_IRON,
                    () -> Ingredient.ofItems(Items.IRON_INGOT),
                    // dyeable = true: the hero's color tints one white texture
                    List.of(new ArmorMaterial.Layer(HeroicMod.id("hero"), "", true),
                            new ArmorMaterial.Layer(HeroicMod.id("hero"), "_overlay", false)),
                    1.0f,
                    0.0f));

    public static final RegistryEntry<ArmorMaterial> GLASSES = Registry.registerReference(
            Registries.ARMOR_MATERIAL, HeroicMod.id("glasses"),
            new ArmorMaterial(
                    Util.make(new EnumMap<>(ArmorItem.Type.class), m -> {
                        m.put(ArmorItem.Type.BOOTS, 0);
                        m.put(ArmorItem.Type.LEGGINGS, 0);
                        m.put(ArmorItem.Type.CHESTPLATE, 0);
                        m.put(ArmorItem.Type.HELMET, 1);
                        m.put(ArmorItem.Type.BODY, 0);
                    }),
                    15,
                    SoundEvents.ITEM_ARMOR_EQUIP_IRON,
                    () -> Ingredient.ofItems(Items.GLASS),
                    List.of(new ArmorMaterial.Layer(HeroicMod.id("glasses"), "", false)),
                    0.0f,
                    0.0f));

    private ModArmorMaterials() {}

    public static void init() {}
}
