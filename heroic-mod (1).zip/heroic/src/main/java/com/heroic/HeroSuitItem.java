package com.heroic;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.DyedColorComponent;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/** One item class per slot; the hero is stored in the HERO_ID component. */
public class HeroSuitItem extends ArmorItem {
    public HeroSuitItem(RegistryEntry<ArmorMaterial> material, Type type, Settings settings) {
        super(material, type, settings);
    }

    @Override
    public Text getName(ItemStack stack) {
        Identifier hero = stack.get(ModComponents.HERO_ID);
        if (hero == null) return super.getName(stack);
        return Text.translatable("hero." + hero.getNamespace() + "." + hero.getPath())
                .append(Text.literal(" "))
                .append(Text.translatable("suit.heroic." + getType().getName()));
    }

    public static ItemStack stackFor(Item item, HeroDefinition hero) {
        ItemStack stack = new ItemStack(item);
        stack.set(ModComponents.HERO_ID, hero.id());
        stack.set(DataComponentTypes.DYED_COLOR, new DyedColorComponent(hero.color(), false));
        return stack;
    }

    public static Identifier heroOf(ItemStack stack) {
        return stack.get(ModComponents.HERO_ID);
    }
}
