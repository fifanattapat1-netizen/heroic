package com.heroic.net;

import com.heroic.HeroicMod;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

import java.util.List;

/**
 * Server -> client: energy, active powers (bitmask by slot), cooldown ticks per slot, and
 * gemInfo = gemMask (bits 0-5) | selectedGem (bits 6-8) | selected gem cooldown seconds (bits 9-16).
 */
public record HeroSyncPayload(Identifier hero, float energy, int maxEnergy, int activeMask,
                              List<Integer> cooldowns, int gemInfo) implements CustomPayload {
    public static final Identifier NONE = HeroicMod.id("none");
    public static final Id<HeroSyncPayload> ID = new Id<>(HeroicMod.id("hero_sync"));
    public static final PacketCodec<RegistryByteBuf, HeroSyncPayload> CODEC = PacketCodec.tuple(
            Identifier.PACKET_CODEC, HeroSyncPayload::hero,
            PacketCodecs.FLOAT, HeroSyncPayload::energy,
            PacketCodecs.VAR_INT, HeroSyncPayload::maxEnergy,
            PacketCodecs.VAR_INT, HeroSyncPayload::activeMask,
            PacketCodecs.VAR_INT.collect(PacketCodecs.toList()), HeroSyncPayload::cooldowns,
            PacketCodecs.VAR_INT, HeroSyncPayload::gemInfo,
            HeroSyncPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() { return ID; }
}
