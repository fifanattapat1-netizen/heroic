package com.heroic.net;

import com.heroic.HeroicMod;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Server -> client: white screen flash. */
public record SnapFlashPayload(int ticks) implements CustomPayload {
    public static final Id<SnapFlashPayload> ID = new Id<>(HeroicMod.id("snap_flash"));
    public static final PacketCodec<RegistryByteBuf, SnapFlashPayload> CODEC =
            PacketCodec.tuple(PacketCodecs.VAR_INT, SnapFlashPayload::ticks, SnapFlashPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() { return ID; }
}
