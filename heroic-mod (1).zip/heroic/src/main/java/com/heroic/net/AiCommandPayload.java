package com.heroic.net;

import com.heroic.HeroicMod;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

public record AiCommandPayload(int cmd) implements CustomPayload {
    public static final Id<AiCommandPayload> ID = new Id<>(HeroicMod.id("ai_command"));
    public static final PacketCodec<RegistryByteBuf, AiCommandPayload> CODEC =
            PacketCodec.tuple(PacketCodecs.VAR_INT, AiCommandPayload::cmd, AiCommandPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() { return ID; }
}
