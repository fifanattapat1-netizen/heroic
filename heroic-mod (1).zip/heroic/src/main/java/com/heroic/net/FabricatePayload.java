package com.heroic.net;

import com.heroic.HeroicMod;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

public record FabricatePayload(Identifier hero) implements CustomPayload {
    public static final Id<FabricatePayload> ID = new Id<>(HeroicMod.id("fabricate"));
    public static final PacketCodec<RegistryByteBuf, FabricatePayload> CODEC =
            PacketCodec.tuple(Identifier.PACKET_CODEC, FabricatePayload::hero, FabricatePayload::new);

    @Override
    public Id<? extends CustomPayload> getId() { return ID; }
}
