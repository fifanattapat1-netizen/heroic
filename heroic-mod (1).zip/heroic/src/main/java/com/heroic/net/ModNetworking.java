package com.heroic.net;

import com.heroic.AiSystem;
import com.heroic.Fabrication;
import com.heroic.GemSystem;
import com.heroic.NanoSystem;
import com.heroic.HeroManager;
import com.heroic.HeroStates;
import com.heroic.HeroTicker;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.ArrayList;

public final class ModNetworking {
    private ModNetworking() {}

    public static void init() {
        PayloadTypeRegistry.playC2S().register(ActivatePowerPayload.ID, ActivatePowerPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(FabricatePayload.ID, FabricatePayload.CODEC);
        PayloadTypeRegistry.playC2S().register(AiCommandPayload.ID, AiCommandPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(GemCommandPayload.ID, GemCommandPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(SnapFlashPayload.ID, SnapFlashPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(HeroSyncPayload.ID, HeroSyncPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(HeroListPayload.ID, HeroListPayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(ActivatePowerPayload.ID, (payload, ctx) ->
                ctx.server().execute(() -> HeroTicker.activate(ctx.player(), payload.slot())));
        ServerPlayNetworking.registerGlobalReceiver(FabricatePayload.ID, (payload, ctx) ->
                ctx.server().execute(() -> Fabrication.fabricate(ctx.player(), payload.hero())));

        ServerPlayNetworking.registerGlobalReceiver(AiCommandPayload.ID, (payload, ctx) ->
                ctx.server().execute(() -> AiSystem.command(ctx.player(), payload.cmd())));

        ServerPlayNetworking.registerGlobalReceiver(GemCommandPayload.ID, (payload, ctx) ->
                ctx.server().execute(() -> {
                    if (payload.cmd() == 3) NanoSystem.toggle(ctx.player(), null);
                    else GemSystem.command(ctx.player(), payload.cmd());
                }));

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity p = handler.player;
            sendHeroList(p);
            // flight leaves allowFlying in the save file; reset it to the game mode default
            p.interactionManager.getGameMode().setAbilities(p.getAbilities());
            p.getAbilities().setFlySpeed(0.05f);
            p.sendAbilitiesUpdate();
        });
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> HeroStates.remove(handler.player));
        ServerLifecycleEvents.END_DATA_PACK_RELOAD.register((server, rm, ok) -> {
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) sendHeroList(p);
        });
        ServerTickEvents.END_SERVER_TICK.register(HeroTicker::tick);
    }

    private static void sendHeroList(ServerPlayerEntity p) {
        ServerPlayNetworking.send(p, new HeroListPayload(new ArrayList<>(HeroManager.all())));
    }
}
