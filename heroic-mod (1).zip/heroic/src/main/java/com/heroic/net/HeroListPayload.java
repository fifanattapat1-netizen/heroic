package com.heroic.net;

import com.heroic.HeroDefinition;
import com.heroic.HeroicMod;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

import java.util.List;

/** Server -> client: every hero definition (so clients need no datapack of their own). */
public record HeroListPayload(List<HeroDefinition> heroes) implements CustomPayload {
    public static final Id<HeroListPayload> ID = new Id<>(HeroicMod.id("hero_list"));
    public static final PacketCodec<RegistryByteBuf, HeroListPayload> CODEC = PacketCodec.tuple(
            HeroDefinition.PACKET_CODEC.collect(PacketCodecs.toList()), HeroListPayload::heroes,
            HeroListPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() { return ID; }
}
