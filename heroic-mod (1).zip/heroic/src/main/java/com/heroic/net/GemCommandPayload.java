package com.heroic.net;

import com.heroic.HeroicMod;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** 0 = cycle gem, 1 = use gem, 2 = snap, 3 = nano deploy/retract. */
public record GemCommandPayload(int cmd) implements CustomPayload {
    public static final Id<GemCommandPayload> ID = new Id<>(HeroicMod.id("gem_command"));
    public static final PacketCodec<RegistryByteBuf, GemCommandPayload> CODEC =
            PacketCodec.tuple(PacketCodecs.VAR_INT, GemCommandPayload::cmd, GemCommandPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() { return ID; }
}
