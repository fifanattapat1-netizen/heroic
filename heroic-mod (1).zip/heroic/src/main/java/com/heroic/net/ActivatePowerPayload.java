package com.heroic.net;

import com.heroic.HeroicMod;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

public record ActivatePowerPayload(int slot) implements CustomPayload {
    public static final Id<ActivatePowerPayload> ID = new Id<>(HeroicMod.id("activate_power"));
    public static final PacketCodec<RegistryByteBuf, ActivatePowerPayload> CODEC =
            PacketCodec.tuple(PacketCodecs.VAR_INT, ActivatePowerPayload::slot, ActivatePowerPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() { return ID; }
}
