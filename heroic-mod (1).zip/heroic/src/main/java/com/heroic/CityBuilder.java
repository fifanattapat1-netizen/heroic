package com.heroic;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.LeavesBlock;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Random;
import java.util.UUID;

/**
 * Builds a Manhattan-style city (roads, glass skyscrapers, apartments, parks, plazas and the central
 * "Arc Tower" with a landing pad) around the player, a few steps per tick so the server doesn't freeze.
 * Best used on a flat area / superflat world: terrain higher than ~8 blocks above the player is not cleared.
 */
public final class CityBuilder {
    private static final int LOT = 20, ROAD = 8, PITCH = LOT + ROAD;
    private static final int FLAGS = Block.NOTIFY_LISTENERS | Block.FORCE_STATE;
    private static final int STEPS_PER_TICK = 6;

    private static final BlockState AIR = Blocks.AIR.getDefaultState();
    private static final BlockState ASPHALT = Blocks.GRAY_CONCRETE.getDefaultState();
    private static final BlockState SIDEWALK = Blocks.LIGHT_GRAY_CONCRETE.getDefaultState();
    private static final BlockState LINE = Blocks.YELLOW_CONCRETE.getDefaultState();
    private static final BlockState LANTERN = Blocks.SEA_LANTERN.getDefaultState();

    private static final Deque<Runnable> QUEUE = new ArrayDeque<>();
    private static int total, done, lastQuarter;
    private static UUID who;
    private static BlockPos tower;

    private CityBuilder() {}

    public static boolean busy() {
        return !QUEUE.isEmpty();
    }

    public static void tick(MinecraftServer server) {
        if (QUEUE.isEmpty()) return;
        for (int i = 0; i < STEPS_PER_TICK && !QUEUE.isEmpty(); i++) {
            QUEUE.poll().run();
            done++;
        }
        ServerPlayerEntity p = who == null ? null : server.getPlayerManager().getPlayer(who);
        if (QUEUE.isEmpty()) {
            if (p != null) p.sendMessage(Text.literal("City complete! Arc Tower at "
                    + tower.getX() + ", " + tower.getY() + ", " + tower.getZ()), false);
        } else {
            int q = done * 4 / Math.max(1, total);
            if (q > lastQuarter) {
                lastQuarter = q;
                if (p != null) p.sendMessage(Text.literal("City: " + (q * 25) + "%"), true);
            }
        }
    }

    public static void start(ServerPlayerEntity player, int lots) {
        ServerWorld w = player.getServerWorld();
        BlockPos c = player.getBlockPos();
        int span = lots * PITCH + ROAD;
        int ox = c.getX() - span / 2, oz = c.getZ() - span / 2, y0 = c.getY();
        Random rnd = new Random(w.getSeed() ^ (ox * 73856093L) ^ (oz * 19349663L));
        who = player.getUuid();
        QUEUE.clear();

        // roads (in 16-row strips)
        for (int z = 0; z < span; z += 16) {
            final int zs = oz + z, ze = Math.min(oz + z + 15, oz + span - 1);
            QUEUE.add(() -> {
                fill(w, ox, y0 - 1, zs, ox + span - 1, y0 - 1, ze, ASPHALT);
                fill(w, ox, y0, zs, ox + span - 1, y0 + 7, ze, AIR);
            });
        }
        QUEUE.add(() -> markings(w, ox, oz, span, lots, y0));

        int mid = lots / 2;
        for (int gz = 0; gz < lots; gz++) {
            for (int gx = 0; gx < lots; gx++) {
                final int lx = ox + ROAD + gx * PITCH, lz = oz + ROAD + gz * PITCH;
                QUEUE.add(() -> foundation(w, lx, lz, y0));
                if (gx == mid && gz == mid) {
                    queueArcTower(w, lx, lz, y0);
                    tower = new BlockPos(lx + LOT / 2, y0, lz + LOT / 2);
                    continue;
                }
                int roll = rnd.nextInt(100);
                if (roll < 45) {
                    int floors = 8 + rnd.nextInt(13);
                    BlockState pillar = pick(rnd, Blocks.WHITE_CONCRETE, Blocks.POLISHED_ANDESITE,
                            Blocks.QUARTZ_BLOCK, Blocks.GRAY_CONCRETE);
                    BlockState glass = pick(rnd, Blocks.LIGHT_BLUE_STAINED_GLASS, Blocks.CYAN_STAINED_GLASS,
                            Blocks.GRAY_STAINED_GLASS, Blocks.BLUE_STAINED_GLASS);
                    queueBuilding(w, lx + 3, lz + 3, 14, y0, floors, true, pillar, glass, true);
                } else if (roll < 75) {
                    int floors = 3 + rnd.nextInt(5);
                    BlockState brick = pick(rnd, Blocks.BRICKS, Blocks.STONE_BRICKS, Blocks.TERRACOTTA, Blocks.BRICKS);
                    queueBuilding(w, lx + 2, lz + 2, 16, y0, floors, false, brick,
                            Blocks.GLASS.getDefaultState(), false);
                } else if (roll < 90) {
                    queuePark(w, lx, lz, y0, rnd);
                } else {
                    queuePlaza(w, lx, lz, y0);
                }
            }
        }
        total = QUEUE.size();
        done = 0;
        lastQuarter = 0;
    }

    // ---------------- helpers ----------------

    private static BlockState pick(Random r, Block... blocks) {
        return blocks[r.nextInt(blocks.length)].getDefaultState();
    }

    private static void set(ServerWorld w, int x, int y, int z, BlockState s) {
        w.setBlockState(new BlockPos(x, y, z), s, FLAGS);
    }

    private static void fill(ServerWorld w, int x0, int y0, int z0, int x1, int y1, int z1, BlockState s) {
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int x = x0; x <= x1; x++)
            for (int y = y0; y <= y1; y++)
                for (int z = z0; z <= z1; z++)
                    w.setBlockState(m.set(x, y, z), s, FLAGS);
    }

    private static void markings(ServerWorld w, int ox, int oz, int span, int lots, int y0) {
        for (int k = 0; k <= lots; k++) {
            int c = k * PITCH + ROAD / 2;
            for (int t = 0; t < span; t++) {
                if (t % 6 < 3) {
                    set(w, ox + c, y0 - 1, oz + t, LINE);
                    set(w, ox + t, y0 - 1, oz + c, LINE);
                }
            }
        }
    }

    private static void lamp(ServerWorld w, int x, int z, int y0) {
        BlockState post = Blocks.COBBLESTONE_WALL.getDefaultState();
        for (int k = 0; k < 4; k++) set(w, x, y0 + k, z, post);
        set(w, x, y0 + 4, z, Blocks.LANTERN.getDefaultState());
    }

    private static void foundation(ServerWorld w, int lx, int lz, int y0) {
        fill(w, lx, y0 - 6, lz, lx + LOT - 1, y0 - 2, lz + LOT - 1, Blocks.STONE.getDefaultState());
        fill(w, lx, y0 - 1, lz, lx + LOT - 1, y0 - 1, lz + LOT - 1, SIDEWALK);
        fill(w, lx, y0, lz, lx + LOT - 1, y0 + 8, lz + LOT - 1, AIR);
        lamp(w, lx + 1, lz + 1, y0);
        lamp(w, lx + LOT - 2, lz + 1, y0);
        lamp(w, lx + 1, lz + LOT - 2, y0);
        lamp(w, lx + LOT - 2, lz + LOT - 2, y0);
    }

    // ---------------- buildings ----------------

    private static void queueBuilding(ServerWorld w, int x0, int z0, int size, int y0, int floors,
                                      boolean fullGlass, BlockState solid, BlockState glass, boolean antenna) {
        BlockState slab = fullGlass ? Blocks.SMOOTH_QUARTZ.getDefaultState() : Blocks.STONE.getDefaultState();
        for (int f = 0; f < floors; f++) {
            final int y = y0 + f * 4;
            final boolean door = f == 0;
            QUEUE.add(() -> floor(w, x0, z0, size, size, y, solid, glass, slab, fullGlass, door));
        }
        QUEUE.add(() -> roof(w, x0, z0, size, size, y0 + floors * 4, solid, antenna));
    }

    private static void floor(ServerWorld w, int x0, int z0, int sx, int sz, int y,
                              BlockState solid, BlockState glass, BlockState slab,
                              boolean fullGlass, boolean door) {
        fill(w, x0, y, z0, x0 + sx - 1, y, z0 + sz - 1, slab);
        fill(w, x0 + 1, y + 1, z0 + 1, x0 + sx - 2, y + 3, z0 + sz - 2, AIR);
        for (int i = 0; i < sx; i++) {
            for (int j = 0; j < sz; j++) {
                boolean xe = i == 0 || i == sx - 1, ze = j == 0 || j == sz - 1;
                if (!xe && !ze) continue;
                boolean corner = xe && ze;
                boolean pillar = corner || (xe ? j % 4 == 0 : i % 4 == 0);
                for (int k = 1; k <= 3; k++) {
                    BlockState s;
                    if (pillar) s = solid;
                    else if (fullGlass) s = glass;
                    else s = (k == 2 && (i + j) % 2 == 1) ? glass : solid;
                    set(w, x0 + i, y + k, z0 + j, s);
                }
            }
        }
        set(w, x0 + sx / 2, y + 3, z0 + sz / 2, LANTERN);
        if (door) {
            fill(w, x0 + sx / 2 - 1, y + 1, z0, x0 + sx / 2, y + 2, z0, AIR);
        }
    }

    private static void roof(ServerWorld w, int x0, int z0, int sx, int sz, int y, BlockState solid, boolean antenna) {
        fill(w, x0, y, z0, x0 + sx - 1, y, z0 + sz - 1, solid);
        for (int i = 0; i < sx; i++) {
            set(w, x0 + i, y + 1, z0, solid);
            set(w, x0 + i, y + 1, z0 + sz - 1, solid);
        }
        for (int j = 0; j < sz; j++) {
            set(w, x0, y + 1, z0 + j, solid);
            set(w, x0 + sx - 1, y + 1, z0 + j, solid);
        }
        if (antenna) {
            int cx = x0 + sx / 2, cz = z0 + sz / 2;
            for (int k = 1; k <= 7; k++) set(w, cx, y + k, cz, Blocks.IRON_BARS.getDefaultState());
            set(w, cx, y + 8, cz, LANTERN);
        }
    }

    // ---------------- park & plaza ----------------

    private static void queuePark(ServerWorld w, int lx, int lz, int y0, Random rnd) {
        int[][] trees = new int[6][2];
        for (int[] t : trees) {
            t[0] = lx + 4 + rnd.nextInt(LOT - 8);
            t[1] = lz + 4 + rnd.nextInt(LOT - 8);
        }
        QUEUE.add(() -> {
            fill(w, lx + 2, y0 - 1, lz + 2, lx + LOT - 3, y0 - 1, lz + LOT - 3, Blocks.GRASS_BLOCK.getDefaultState());
            fill(w, lx + LOT / 2 - 1, y0 - 1, lz + 2, lx + LOT / 2, y0 - 1, lz + LOT - 3, Blocks.DIRT_PATH.getDefaultState());
            fill(w, lx + 2, y0 - 1, lz + LOT / 2 - 1, lx + LOT - 3, y0 - 1, lz + LOT / 2, Blocks.DIRT_PATH.getDefaultState());
            for (int[] t : trees) tree(w, t[0], t[1], y0);
        });
    }

    private static void tree(ServerWorld w, int x, int z, int y0) {
        BlockState leaves = Blocks.OAK_LEAVES.getDefaultState().with(LeavesBlock.PERSISTENT, true);
        for (int k = 0; k < 5; k++) set(w, x, y0 + k, z, Blocks.OAK_LOG.getDefaultState());
        for (int dy = 3; dy <= 6; dy++) {
            int r = dy >= 6 ? 0 : (dy == 5 ? 1 : 2);
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    if (r == 2 && Math.abs(dx) == 2 && Math.abs(dz) == 2) continue;
                    if (dx == 0 && dz == 0 && dy <= 4) continue;
                    set(w, x + dx, y0 + dy, z + dz, leaves);
                }
            }
        }
    }

    private static void queuePlaza(ServerWorld w, int lx, int lz, int y0) {
        QUEUE.add(() -> {
            int cx = lx + LOT / 2, cz = lz + LOT / 2;
            BlockState brick = Blocks.STONE_BRICKS.getDefaultState();
            fill(w, cx - 3, y0, cz - 3, cx + 3, y0, cz + 3, brick);
            fill(w, cx - 2, y0, cz - 2, cx + 2, y0, cz + 2, Blocks.WATER.getDefaultState());
            for (int k = 0; k < 3; k++) set(w, cx, y0 + k, cz, Blocks.QUARTZ_PILLAR.getDefaultState());
            set(w, cx, y0 + 3, cz, LANTERN);
        });
    }

    // ---------------- Arc Tower ----------------

    private static void queueArcTower(ServerWorld w, int lx, int lz, int y0) {
        int cx = lx + LOT / 2, cz = lz + LOT / 2;
        int[][] tiers = {{18, 8}, {14, 7}, {10, 6}, {6, 5}};
        BlockState solid = Blocks.QUARTZ_BLOCK.getDefaultState();
        BlockState glass = Blocks.LIGHT_BLUE_STAINED_GLASS.getDefaultState();
        BlockState slab = Blocks.SMOOTH_QUARTZ.getDefaultState();
        int y = y0;
        for (int t = 0; t < tiers.length; t++) {
            final int size = tiers[t][0], floors = tiers[t][1], x0 = cx - size / 2, z0 = cz - size / 2;
            for (int f = 0; f < floors; f++) {
                final int yy = y + f * 4;
                final boolean door = t == 0 && f == 0;
                QUEUE.add(() -> floor(w, x0, z0, size, size, yy, solid, glass, slab, true, door));
            }
            final int top = y + floors * 4;
            QUEUE.add(() -> roof(w, x0, z0, size, size, top, solid, false));
            if (t == 0) {
                final int ringY = y0 + 14;
                QUEUE.add(() -> arcRings(w, x0, z0, size, ringY));
                QUEUE.add(() -> landingPad(w, x0 + size, cz, top));
            }
            y = top;
        }
        final int spireBase = y;
        QUEUE.add(() -> {
            for (int k = 1; k <= 18; k++) set(w, cx, spireBase + k, cz, Blocks.IRON_BARS.getDefaultState());
            set(w, cx, spireBase + 19, cz, LANTERN);
        });
    }

    /** Glowing "arc reactor" ring on every face of the base tier. */
    private static void arcRings(ServerWorld w, int x0, int z0, int size, int yc) {
        int cx = x0 + size / 2, cz = z0 + size / 2;
        for (int dx = -4; dx <= 4; dx++) {
            for (int dy = -4; dy <= 4; dy++) {
                double d = Math.sqrt(dx * dx + dy * dy);
                BlockState s = null;
                if (d >= 2.5 && d <= 3.5) s = LANTERN;
                else if (d < 1.3) s = Blocks.GLOWSTONE.getDefaultState();
                if (s == null) continue;
                set(w, cx + dx, yc + dy, z0, s);
                set(w, cx + dx, yc + dy, z0 + size - 1, s);
                set(w, x0, yc + dy, cz + dx, s);
                set(w, x0 + size - 1, yc + dy, cz + dx, s);
            }
        }
    }

    private static void landingPad(ServerWorld w, int xStart, int cz, int y) {
        fill(w, xStart, y, cz - 4, xStart + 7, y, cz + 3, Blocks.GRAY_CONCRETE.getDefaultState());
        fill(w, xStart + 2, y, cz - 1, xStart + 5, y, cz, Blocks.WHITE_CONCRETE.getDefaultState());
        for (int[] c : new int[][]{{xStart, cz - 4}, {xStart + 7, cz - 4}, {xStart, cz + 3}, {xStart + 7, cz + 3}})
            set(w, c[0], y, c[1], LANTERN);
    }
}
