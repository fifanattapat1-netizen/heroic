package com.heroic.entity;

import com.heroic.ModEntities;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/** A flying guard drone that follows its owner, shoots hostile mobs and swats incoming projectiles. */
public class DroneEntity extends PathAwareEntity {
    public static final int MAX_PER_PLAYER = 4;

    public UUID ownerId;
    public int orbitIndex;
    private int life = 6000;
    private int fireCooldown;
    private LivingEntity target;

    public DroneEntity(EntityType<? extends PathAwareEntity> type, World world) {
        super(type, world);
        setNoGravity(true);
        setPersistent();
    }

    public static DefaultAttributeContainer.Builder createDroneAttributes() {
        return PathAwareEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 24.0)
                .add(EntityAttributes.GENERIC_FLYING_SPEED, 0.6)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.3);
    }

    public void setOwner(PlayerEntity p) {
        ownerId = p.getUuid();
    }

    @Override
    public boolean shouldSave() {
        return false; // drones vanish when the world is saved/unloaded
    }

    @Override
    public boolean handleFallDamage(float fallDistance, float damageMultiplier, DamageSource source) {
        return false;
    }

    @Override
    public void travel(Vec3d input) {
        if (!getWorld().isClient) {
            move(MovementType.SELF, getVelocity());
            setVelocity(getVelocity().multiply(0.9));
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (!getWorld().isClient) serverTick();
    }

    private PlayerEntity owner() {
        return ownerId == null ? null : getWorld().getPlayerByUuid(ownerId);
    }

    private void serverTick() {
        ServerWorld w = (ServerWorld) getWorld();
        PlayerEntity o = owner();
        if (o == null || !o.isAlive() || --life <= 0) {
            w.spawnParticles(ParticleTypes.POOF, getX(), getY(), getZ(), 10, 0.2, 0.2, 0.2, 0.02);
            discard();
            return;
        }
        if (squaredDistanceTo(o) > 48 * 48) {
            requestTeleport(o.getX(), o.getY() + 2.5, o.getZ());
        }

        // swat projectiles aimed around us / the owner
        for (ProjectileEntity pr : w.getEntitiesByClass(ProjectileEntity.class,
                getBoundingBox().expand(3.0), e -> e.getOwner() != o && e.isAlive())) {
            w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, pr.getX(), pr.getY(), pr.getZ(), 8, 0.1, 0.1, 0.1, 0.1);
            pr.discard();
        }

        if (age % 10 == 0) target = pickTarget(o);
        if (age % 20 == 0 && squaredDistanceTo(o) < 144) {
            o.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 60, 0, true, false, true));
        }

        Vec3d goal;
        if (target != null && target.isAlive()) {
            double a = age * 0.04 + orbitIndex * 2.1;
            goal = target.getPos().add(Math.cos(a) * 6.0, 3.5, Math.sin(a) * 6.0);
            getLookControl().lookAt(target.getX(), target.getEyeY(), target.getZ());
            if (--fireCooldown <= 0 && distanceTo(target) < 14 && canSee(target)) {
                zap(w, o, target);
                fireCooldown = 15;
            }
        } else {
            double a = age * 0.05 + orbitIndex * (Math.PI * 2 / 3);
            goal = o.getPos().add(Math.cos(a) * 3.0, 2.8, Math.sin(a) * 3.0);
            getLookControl().lookAt(o.getX(), o.getEyeY(), o.getZ());
        }

        Vec3d to = goal.subtract(getPos());
        double len = to.length();
        if (len > 0.2) {
            setVelocity(getVelocity().add(to.normalize().multiply(Math.min(0.08, len * 0.05))));
        }
    }

    private LivingEntity pickTarget(PlayerEntity o) {
        LivingEntity attacker = o.getAttacker();
        if (attacker instanceof Monster && attacker.isAlive()) return attacker;
        Box box = o.getBoundingBox().expand(18);
        List<LivingEntity> list = getWorld().getEntitiesByClass(LivingEntity.class, box,
                e -> e instanceof Monster && e.isAlive());
        return list.stream()
                .min(Comparator.comparingDouble(e -> e.squaredDistanceTo(o) - (e instanceof CreeperEntity ? 400 : 0)))
                .orElse(null);
    }

    private void zap(ServerWorld w, PlayerEntity owner, LivingEntity t) {
        Vec3d from = getPos().add(0, 0.2, 0);
        Vec3d to = t.getPos().add(0, t.getHeight() * 0.5, 0);
        Vec3d dir = to.subtract(from);
        double len = dir.length();
        dir = dir.normalize();
        for (double d = 0.5; d < len; d += 0.5) {
            Vec3d p = from.add(dir.multiply(d));
            w.spawnParticles(ParticleTypes.END_ROD, p.x, p.y, p.z, 1, 0, 0, 0, 0);
        }
        t.damage(w.getDamageSources().playerAttack(owner), 4.0f);
        w.playSound(null, getX(), getY(), getZ(), SoundEvents.ENTITY_ARROW_SHOOT, SoundCategory.NEUTRAL, 0.6f, 1.7f);
    }

    // ---------------- helpers ----------------

    public static List<DroneEntity> owned(ServerPlayerEntity p) {
        return p.getServerWorld().getEntitiesByClass(DroneEntity.class, p.getBoundingBox().expand(96),
                d -> p.getUuid().equals(d.ownerId));
    }

    /** Spawns up to `count` drones (max 4 per player). Returns how many were spawned. */
    public static int deploy(ServerPlayerEntity p, int count) {
        ServerWorld w = p.getServerWorld();
        int existing = owned(p).size();
        int n = Math.max(0, Math.min(count, MAX_PER_PLAYER - existing));
        for (int i = 0; i < n; i++) {
            DroneEntity d = ModEntities.DRONE.create(w);
            if (d == null) continue;
            double a = (existing + i) * Math.PI / 2;
            d.refreshPositionAndAngles(p.getX() + Math.cos(a) * 2, p.getY() + 2.5, p.getZ() + Math.sin(a) * 2, 0, 0);
            d.setOwner(p);
            d.orbitIndex = existing + i;
            w.spawnEntity(d);
            w.spawnParticles(ParticleTypes.END_ROD, d.getX(), d.getY(), d.getZ(), 12, 0.3, 0.3, 0.3, 0.05);
        }
        return n;
    }

    public static int recall(ServerPlayerEntity p) {
        List<DroneEntity> list = owned(p);
        for (DroneEntity d : list) {
            p.getServerWorld().spawnParticles(ParticleTypes.POOF, d.getX(), d.getY(), d.getZ(), 8, 0.2, 0.2, 0.2, 0.02);
            d.discard();
        }
        return list.size();
    }
}
