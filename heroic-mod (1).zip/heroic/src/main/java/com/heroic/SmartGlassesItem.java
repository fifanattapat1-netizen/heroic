package com.heroic;

import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.registry.entry.RegistryEntry;

/** Worn in the helmet slot. Wearing it brings the AEGIS assistant online. */
public class SmartGlassesItem extends ArmorItem {
    public SmartGlassesItem(RegistryEntry<ArmorMaterial> material, Type type, Settings settings) {
        super(material, type, settings);
    }
}
