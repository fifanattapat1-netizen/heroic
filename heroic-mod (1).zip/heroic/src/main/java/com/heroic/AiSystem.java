package com.heroic;

import com.heroic.entity.DroneEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;
import java.util.List;

/**
 * AEGIS: the suit/glasses assistant. Server side: warnings, fall assist, emergency protocol, drone orders.
 * (The scanner HUD is client side, see AiHud.)
 */
public final class AiSystem {
    private AiSystem() {}

    public static void tick(ServerPlayerEntity p, PlayerHeroState st, HeroDefinition worn, int now) {
        boolean ai = HeroUtil.hasAi(p, worn);
        if (ai != st.aiOnline) {
            st.aiOnline = ai;
            say(p, ai ? "aegis.online" : "aegis.offline", false);
            if (ai) HeroUtil.sound(p, SoundEvents.BLOCK_BEACON_POWER_SELECT, 1.6f);
        }
        if (!ai) return;
        boolean suit = worn != null && worn.ai();

        // fall assist
        if (p.fallDistance > 12 && !p.isOnGround() && now - st.lastFallMsg > 100) {
            st.lastFallMsg = now;
            if (suit && st.energy >= 15) {
                st.energy -= 15;
                st.dirty = true;
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOW_FALLING, 100, 0, false, false, false));
                say(p, "aegis.fall_assist", true);
            } else {
                say(p, "aegis.fall_warn", true);
            }
        }

        // emergency protocol (full AI suit only)
        if (suit && p.getHealth() <= 4.0f && now >= st.emergencyUntil && st.energy >= 25) {
            st.energy -= 25;
            st.dirty = true;
            st.emergencyUntil = now + 1200;
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.ABSORPTION, 200, 1));
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 100, 1));
            say(p, "aegis.emergency", false);
            HeroUtil.sound(p, SoundEvents.BLOCK_BEACON_ACTIVATE, 0.8f);
        } else if (p.getHealth() <= 6.0f && now - st.lastVitalsMsg > 200) {
            st.lastVitalsMsg = now;
            say(p, "aegis.vitals", true);
        }

        if (now % 20 != 0) return;
        List<LivingEntity> hostiles = p.getServerWorld().getEntitiesByClass(LivingEntity.class,
                p.getBoundingBox().expand(24), e -> e instanceof Monster && e.isAlive());
        if (hostiles.isEmpty()) return;

        for (LivingEntity e : hostiles) {
            if (e instanceof CreeperEntity && e.distanceTo(p) < 6 && now - st.lastCreeperMsg > 60) {
                st.lastCreeperMsg = now;
                say(p, "aegis.creeper", true);
                break;
            }
        }
        if (now - st.lastThreatMsg > 160) {
            st.lastThreatMsg = now;
            LivingEntity nearest = hostiles.stream().min(Comparator.comparingDouble(e -> e.squaredDistanceTo(p))).get();
            Vec3d d = nearest.getPos().subtract(p.getPos());
            Direction dir = Direction.fromRotation(Math.toDegrees(Math.atan2(-d.x, d.z)));
            say(p, "aegis.hostiles", true, hostiles.size(), nearest.getName(),
                    Math.round(nearest.distanceTo(p)), Text.translatable("aegis.dir." + dir.asString()));
        }
    }

    /** 0 = deploy drones, 1 = recall drones. */
    public static void command(ServerPlayerEntity p, int cmd) {
        HeroDefinition worn = HeroUtil.wornHero(p);
        if (!HeroUtil.hasAi(p, worn)) return;
        PlayerHeroState st = HeroStates.get(p);
        int now = p.getServer().getTicks();
        if (cmd == 0) {
            if (now < st.droneCooldownUntil) {
                say(p, "aegis.cooldown", true, (st.droneCooldownUntil - now + 19) / 20);
                return;
            }
            int n = DroneEntity.deploy(p, 2);
            if (n > 0) {
                st.droneCooldownUntil = now + 600;
                say(p, "aegis.deployed", true, n);
                HeroUtil.sound(p, SoundEvents.BLOCK_BEACON_ACTIVATE, 1.8f);
            } else {
                say(p, "aegis.max_drones", true);
            }
        } else if (cmd == 1) {
            say(p, "aegis.recalled", true, DroneEntity.recall(p));
        }
    }

    public static void say(ServerPlayerEntity p, String key, boolean actionBar, Object... args) {
        p.sendMessage(Text.literal("[AEGIS] ").formatted(Formatting.AQUA)
                .append(Text.translatable(key, args).formatted(Formatting.WHITE)), actionBar);
    }
}
