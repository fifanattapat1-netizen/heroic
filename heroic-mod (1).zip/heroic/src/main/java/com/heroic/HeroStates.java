package com.heroic;

import net.minecraft.server.network.ServerPlayerEntity;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class HeroStates {
    private static final Map<UUID, PlayerHeroState> STATES = new ConcurrentHashMap<>();

    private HeroStates() {}

    public static PlayerHeroState get(ServerPlayerEntity p) {
        return STATES.computeIfAbsent(p.getUuid(), u -> new PlayerHeroState());
    }

    public static void remove(ServerPlayerEntity p) {
        STATES.remove(p.getUuid());
    }
}
