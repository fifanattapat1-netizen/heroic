package com.heroic;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

/** Server-side logic of the Suit Fabricator. Cost is for a whole 4-piece suit. */
public final class Fabrication {
    public static final int IRON = 24;
    public static final int DIAMONDS = 4;
    public static final int LEATHER = 4;

    private Fabrication() {}

    public static void fabricate(ServerPlayerEntity p, Identifier heroId) {
        HeroDefinition hero = HeroManager.get(heroId);
        if (hero == null || !nearFabricator(p)) return;

        boolean free = p.isCreative();
        if (!free && (count(p, Items.IRON_INGOT) < IRON
                || count(p, Items.DIAMOND) < DIAMONDS
                || count(p, Items.LEATHER) < LEATHER)) {
            p.sendMessage(Text.translatable("message.heroic.missing_materials", IRON, DIAMONDS, LEATHER), true);
            return;
        }
        if (!free) {
            remove(p, Items.IRON_INGOT, IRON);
            remove(p, Items.DIAMOND, DIAMONDS);
            remove(p, Items.LEATHER, LEATHER);
        }
        for (Item piece : ModItems.SUIT_PIECES) {
            p.getInventory().offerOrDrop(HeroSuitItem.stackFor(piece, hero));
        }
        HeroUtil.sound(p, SoundEvents.BLOCK_SMITHING_TABLE_USE, 1.0f);
        p.sendMessage(Text.translatable("message.heroic.fabricated", Text.translatable(hero.translationKey())), true);
    }

    private static boolean nearFabricator(ServerPlayerEntity p) {
        BlockPos c = p.getBlockPos();
        for (BlockPos b : BlockPos.iterate(c.add(-6, -4, -6), c.add(6, 4, 6))) {
            if (p.getWorld().getBlockState(b).isOf(ModBlocks.SUIT_FABRICATOR)) return true;
        }
        return false;
    }

    private static int count(PlayerEntity p, Item item) {
        int n = 0;
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (s.isOf(item)) n += s.getCount();
        }
        return n;
    }

    private static void remove(PlayerEntity p, Item item, int amount) {
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.size() && amount > 0; i++) {
            ItemStack s = inv.getStack(i);
            if (s.isOf(item)) {
                int take = Math.min(amount, s.getCount());
                s.decrement(take);
                amount -= take;
            }
        }
    }
}
