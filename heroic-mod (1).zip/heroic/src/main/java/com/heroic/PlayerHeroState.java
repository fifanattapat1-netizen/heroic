package com.heroic;

import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

/** Server-side, per-player runtime state (not saved to disk). */
public class PlayerHeroState {
    public Identifier hero;
    public float energy;
    public final Set<Identifier> active = new LinkedHashSet<>();
    public final Map<Identifier, Integer> cooldownUntil = new HashMap<>();
    public boolean pendingSlam;
    public int slamTicks;
    public boolean dirty = true;

    // AEGIS (AI) state
    public boolean aiOnline;
    public int lastThreatMsg = -1000;
    public int lastCreeperMsg = -1000;
    public int lastVitalsMsg = -1000;
    public int lastFallMsg = -1000;
    public int emergencyUntil;
    public int droneCooldownUntil;

    // Core Gems
    public int selectedGem;
    public final int[] gemCooldownUntil = new int[Gems.COUNT];
    public int snapCooldownUntil;

    // Nano deploy / retract animation: >0 deploying (stages left), <0 retracting, 0 idle
    public int nanoStage;
    public int nanoNext;
    public Identifier nanoHero;
    public int nanoGems;
    public float keepEnergy = -1;
}
