package com.heroic;

import com.heroic.net.SnapFlashPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.SheepEntity;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.EntityTypeTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Core Gem abilities (H = use selected gem, G = cycle) and the Snap (J, needs all six gems). */
public final class GemSystem {
    private static final float[] COST = {45, 35, 40, 40, 35, 40};
    private static final int[] CD = {100, 60, 200, 240, 200, 300};
    private static final float SNAP_COST = 100f;
    private static final int SNAP_COOLDOWN = 6000;

    private GemSystem() {}

    /** 0 = cycle gem, 1 = use gem, 2 = snap. */
    public static void command(ServerPlayerEntity p, int cmd) {
        HeroDefinition worn = HeroUtil.wornHero(p);
        if (worn == null) return;
        int mask = Gems.mask(p);
        if (mask == 0) return;
        PlayerHeroState st = HeroStates.get(p);
        int now = p.getServer().getTicks();
        if ((mask >> st.selectedGem & 1) == 0) st.selectedGem = Gems.firstSet(mask);

        if (cmd == 0) {
            st.selectedGem = Gems.nextSelected(mask, st.selectedGem);
            st.dirty = true;
            HeroUtil.sound(p, SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, 1.5f);
        } else if (cmd == 1) {
            useGem(p, st, now);
        } else if (cmd == 2) {
            snap(p, st, mask, now);
        }
    }

    private static void useGem(ServerPlayerEntity p, PlayerHeroState st, int now) {
        int g = st.selectedGem;
        if (now < st.gemCooldownUntil[g]) return;
        if (st.energy < COST[g]) {
            p.sendMessage(Text.translatable("message.heroic.no_energy"), true);
            return;
        }
        boolean ok = switch (g) {
            case 0 -> vigor(p);
            case 1 -> rift(p);
            case 2 -> mirage(p);
            case 3 -> chrono(p);
            case 4 -> psyche(p);
            default -> spirit(p);
        };
        if (!ok) return;
        st.energy -= COST[g];
        st.gemCooldownUntil[g] = now + CD[g];
        st.dirty = true;
    }

    private static Vector3f vec(int rgb) {
        return Vec3d.unpackRgb(rgb).toVector3f();
    }

    private static List<LivingEntity> monsters(ServerPlayerEntity p, double r) {
        return p.getServerWorld().getEntitiesByClass(LivingEntity.class, p.getBoundingBox().expand(r),
                e -> e instanceof Monster && e.isAlive());
    }

    // ---- Vigor (purple): devastating beam ----
    private static boolean vigor(ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        Vec3d start = p.getEyePos().add(0, -0.2, 0);
        Vec3d dir = p.getRotationVec(1.0f);
        LivingEntity t = HeroUtil.traceEntity(p, 40);
        BlockHitResult bh = HeroUtil.traceBlocks(p, 40);
        Vec3d end = t != null ? t.getPos().add(0, t.getHeight() * 0.5, 0) : bh.getPos();
        DustParticleEffect dust = new DustParticleEffect(vec(Gems.COLORS[0]), 1.6f);
        double len = start.distanceTo(end);
        for (double d = 1.0; d < len; d += 0.35) {
            Vec3d at = start.add(dir.multiply(d));
            w.spawnParticles(dust, at.x, at.y, at.z, 2, 0.05, 0.05, 0.05, 0.0);
            w.spawnParticles(ParticleTypes.END_ROD, at.x, at.y, at.z, 1, 0.02, 0.02, 0.02, 0.0);
        }
        w.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, end.x, end.y, end.z, 1, 0, 0, 0, 0);
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, new Box(end, end).expand(4.0),
                en -> en != p && en.isAlive())) {
            e.damage(p.getDamageSources().playerAttack(p), e == t ? 16.0f : 10.0f);
            Vec3d away = e.getPos().subtract(end);
            Vec3d push = new Vec3d(away.x, 0, away.z);
            push = push.lengthSquared() < 1.0E-4 ? Vec3d.ZERO : push.normalize().multiply(0.9);
            e.addVelocity(push.x, 0.45, push.z);
            e.velocityModified = true;
        }
        HeroUtil.sound(p, SoundEvents.ENTITY_FIREWORK_ROCKET_BLAST, 0.5f);
        return true;
    }

    // ---- Rift (blue): long-range blink ----
    private static boolean rift(ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        Vec3d dir = p.getRotationVec(1.0f);
        BlockHitResult bh = HeroUtil.traceBlocks(p, 40);
        Vec3d dest = bh.getType() == HitResult.Type.MISS ? bh.getPos() : bh.getPos().subtract(dir.multiply(0.7));
        for (int dy = 0; dy <= 2; dy++) {
            Vec3d cand = dest.add(0, dy, 0);
            Box moved = p.getBoundingBox().offset(cand.subtract(p.getPos()));
            if (w.isSpaceEmpty(p, moved)) {
                w.spawnParticles(ParticleTypes.PORTAL, p.getX(), p.getY() + 1, p.getZ(), 40, 0.4, 0.8, 0.4, 0.2);
                p.requestTeleport(cand.x, cand.y, cand.z);
                p.fallDistance = 0;
                w.spawnParticles(ParticleTypes.PORTAL, cand.x, cand.y + 1, cand.z, 40, 0.4, 0.8, 0.4, 0.2);
                HeroUtil.sound(p, SoundEvents.ENTITY_ENDERMAN_TELEPORT, 0.8f);
                return true;
            }
        }
        p.sendMessage(Text.translatable("message.heroic.no_space"), true);
        return false;
    }

    // ---- Mirage (red): turn hostile mobs into sheep ----
    private static boolean mirage(ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        int n = 0;
        for (LivingEntity e : monsters(p, 10)) {
            if (e.getType().isIn(EntityTypeTags.BOSSES)) continue;
            SheepEntity sheep = EntityType.SHEEP.create(w);
            if (sheep == null) continue;
            sheep.refreshPositionAndAngles(e.getX(), e.getY(), e.getZ(), e.getYaw(), 0);
            w.spawnEntity(sheep);
            w.spawnParticles(ParticleTypes.HAPPY_VILLAGER, e.getX(), e.getY() + 1, e.getZ(), 15, 0.3, 0.5, 0.3, 0.05);
            e.discard();
            n++;
        }
        if (n == 0) {
            p.sendMessage(Text.translatable("message.heroic.no_targets"), true);
            return false;
        }
        HeroUtil.sound(p, SoundEvents.ENTITY_SHEEP_AMBIENT, 1.0f);
        return true;
    }

    // ---- Chrono (green): slow time around you ----
    private static boolean chrono(ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        for (LivingEntity e : monsters(p, 16)) {
            e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 160, 4));
            e.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 160, 1));
        }
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 160, 1));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.HASTE, 160, 1));
        w.spawnParticles(ParticleTypes.REVERSE_PORTAL, p.getX(), p.getY() + 1, p.getZ(), 60, 1.2, 0.8, 1.2, 0.1);
        HeroUtil.sound(p, SoundEvents.BLOCK_BEACON_DEACTIVATE, 0.5f);
        return true;
    }

    // ---- Psyche (yellow): mobs turn on each other ----
    private static boolean psyche(ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        List<LivingEntity> list = monsters(p, 14);
        if (list.isEmpty()) {
            p.sendMessage(Text.translatable("message.heroic.no_targets"), true);
            return false;
        }
        for (LivingEntity e : list) {
            e.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, 200, 0));
            if (e instanceof MobEntity mob) {
                list.stream().filter(o -> o != e)
                        .min(Comparator.comparingDouble(o -> o.squaredDistanceTo(e)))
                        .ifPresent(mob::setTarget);
            }
            w.spawnParticles(ParticleTypes.ENCHANT, e.getX(), e.getY() + 1.5, e.getZ(), 15, 0.3, 0.3, 0.3, 0.5);
        }
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 600, 0, false, false, false));
        HeroUtil.sound(p, SoundEvents.BLOCK_BEACON_POWER_SELECT, 0.8f);
        return true;
    }

    // ---- Spirit (orange): heal and cleanse ----
    private static boolean spirit(ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        List<ServerPlayerEntity> targets = new ArrayList<>();
        targets.add(p);
        for (ServerPlayerEntity o : w.getPlayers()) if (o != p && o.squaredDistanceTo(p) < 36) targets.add(o);
        for (ServerPlayerEntity t : targets) {
            t.heal(t == p ? 10.0f : 6.0f);
            for (StatusEffectInstance inst : new ArrayList<>(t.getStatusEffects())) {
                if (inst.getEffectType().value().getCategory() == StatusEffectCategory.HARMFUL)
                    t.removeStatusEffect(inst.getEffectType());
            }
            t.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 100, 1));
            w.spawnParticles(ParticleTypes.HEART, t.getX(), t.getY() + 1.5, t.getZ(), 8, 0.4, 0.4, 0.4, 0.0);
            w.spawnParticles(ParticleTypes.SOUL, t.getX(), t.getY() + 1.0, t.getZ(), 15, 0.4, 0.6, 0.4, 0.02);
        }
        HeroUtil.sound(p, SoundEvents.BLOCK_BEACON_POWER_SELECT, 1.2f);
        return true;
    }

    // ---- The Snap: half of all hostile mobs nearby turn to ash ----
    private static void snap(ServerPlayerEntity p, PlayerHeroState st, int mask, int now) {
        if (mask != Gems.ALL) {
            p.sendMessage(Text.translatable("message.heroic.snap_need_gems"), true);
            return;
        }
        if (now < st.snapCooldownUntil) {
            p.sendMessage(Text.translatable("message.heroic.snap_cooldown", (st.snapCooldownUntil - now + 19) / 20), true);
            return;
        }
        if (st.energy < SNAP_COST) {
            p.sendMessage(Text.translatable("message.heroic.no_energy"), true);
            return;
        }
        ServerWorld w = p.getServerWorld();
        p.swingHand(Hand.MAIN_HAND, true);
        for (ServerPlayerEntity o : w.getPlayers()) {
            if (o.squaredDistanceTo(p) < 96 * 96) ServerPlayNetworking.send(o, new SnapFlashPayload(40));
        }
        HeroUtil.sound(p, SoundEvents.ENTITY_FIREWORK_ROCKET_LARGE_BLAST, 0.5f);
        HeroUtil.sound(p, SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 0.6f);

        List<LivingEntity> mobs = new ArrayList<>(w.getEntitiesByClass(LivingEntity.class,
                p.getBoundingBox().expand(64),
                e -> e instanceof Monster && e.isAlive() && !e.getType().isIn(EntityTypeTags.BOSSES)));
        Collections.shuffle(mobs);
        int n = mobs.size() / 2;
        for (int i = 0; i < n; i++) {
            LivingEntity e = mobs.get(i);
            w.spawnParticles(ParticleTypes.ASH, e.getX(), e.getY() + e.getHeight() * 0.5, e.getZ(),
                    60, 0.4, 0.6, 0.4, 0.08);
            w.spawnParticles(ParticleTypes.SMOKE, e.getX(), e.getY() + e.getHeight() * 0.5, e.getZ(),
                    15, 0.3, 0.5, 0.3, 0.02);
            e.discard();
        }
        st.energy = 0;
        st.snapCooldownUntil = now + SNAP_COOLDOWN;
        st.dirty = true;
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 200, 1));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 200, 0));
        p.sendMessage(Text.translatable("message.heroic.snap_done", n), true);
    }
}
