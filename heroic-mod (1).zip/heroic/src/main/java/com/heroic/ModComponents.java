package com.heroic;

import com.mojang.serialization.Codec;
import net.minecraft.component.ComponentType;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModComponents {
    /** Which hero a suit piece / nano core belongs to. */
    public static final ComponentType<Identifier> HERO_ID = Registry.register(
            Registries.DATA_COMPONENT_TYPE, HeroicMod.id("hero_id"),
            ComponentType.<Identifier>builder()
                    .codec(Identifier.CODEC)
                    .packetCodec(Identifier.PACKET_CODEC)
                    .build());

    /** Bitmask of Core Gems socketed into a suit chestplate (or stored in a nano core). */
    public static final ComponentType<Integer> GEMS = Registry.register(
            Registries.DATA_COMPONENT_TYPE, HeroicMod.id("gems"),
            ComponentType.<Integer>builder()
                    .codec(Codec.INT)
                    .packetCodec(PacketCodecs.VAR_INT)
                    .build());

    private ModComponents() {}

    public static void init() {}
}
