package com.heroic;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.mojang.serialization.JsonOps;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.resource.ResourceManager;
import net.minecraft.resource.ResourceType;
import net.minecraft.util.Identifier;

import java.io.Reader;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

public final class HeroManager {
    private static volatile Map<Identifier, HeroDefinition> heroes = Map.of();

    private HeroManager() {}

    public static Collection<HeroDefinition> all() {
        return heroes.values();
    }

    public static HeroDefinition get(Identifier id) {
        return id == null ? null : heroes.get(id);
    }

    /** Used by the client when the server sends its hero list. */
    public static void setAll(Collection<HeroDefinition> list) {
        Map<Identifier, HeroDefinition> m = new LinkedHashMap<>();
        for (HeroDefinition h : list) m.put(h.id(), h);
        heroes = m;
    }

    public static void init() {
        ResourceManagerHelper.get(ResourceType.SERVER_DATA).registerReloadListener(
                new SimpleSynchronousResourceReloadListener() {
                    @Override
                    public Identifier getFabricId() {
                        return HeroicMod.id("heroes");
                    }

                    @Override
                    public void reload(ResourceManager manager) {
                        Map<Identifier, HeroDefinition> loaded = new LinkedHashMap<>();
                        var found = manager.findResources("heroes", id -> id.getPath().endsWith(".json"));
                        for (var entry : found.entrySet()) {
                            Identifier file = entry.getKey();
                            String p = file.getPath();
                            Identifier id = Identifier.of(file.getNamespace(),
                                    p.substring("heroes/".length(), p.length() - ".json".length()));
                            try (Reader reader = entry.getValue().getReader()) {
                                JsonElement json = JsonParser.parseReader(reader);
                                HeroDefinition.Data.CODEC.parse(JsonOps.INSTANCE, json)
                                        .resultOrPartial(err -> HeroicMod.LOGGER.error("Hero {}: {}", id, err))
                                        .ifPresent(d -> loaded.put(id, new HeroDefinition(id, d)));
                            } catch (Exception ex) {
                                HeroicMod.LOGGER.error("Failed to read hero {}", id, ex);
                            }
                        }
                        heroes = loaded;
                        HeroicMod.LOGGER.info("Loaded {} heroes", loaded.size());
                    }
                });
    }
}
