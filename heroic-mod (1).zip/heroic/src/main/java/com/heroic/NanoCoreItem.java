package com.heroic;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** Holds a whole suit as nanites. Right-click (or press K) to deploy / retract it. */
public class NanoCoreItem extends Item {
    public NanoCoreItem(Settings settings) {
        super(settings);
    }

    @Override
    public boolean hasGlint(ItemStack stack) {
        return stack.contains(ModComponents.HERO_ID);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient) NanoSystem.toggle((ServerPlayerEntity) user, stack);
        return TypedActionResult.success(stack, world.isClient);
    }
}
