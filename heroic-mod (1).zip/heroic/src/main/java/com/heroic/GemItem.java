package com.heroic;

import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** Right-click while wearing a hero chestplate to socket the gem into it. */
public class GemItem extends Item {
    private final int index;

    public GemItem(Settings settings, int index) {
        super(settings);
        this.index = index;
    }

    @Override
    public boolean hasGlint(ItemStack stack) {
        return true;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack held = user.getStackInHand(hand);
        ItemStack chest = user.getEquippedStack(EquipmentSlot.CHEST);
        if (!(chest.getItem() instanceof HeroSuitItem)) {
            if (!world.isClient) user.sendMessage(Text.translatable("message.heroic.gem_need_suit"), true);
            return TypedActionResult.fail(held);
        }
        int mask = Gems.mask(user);
        int bit = 1 << index;
        if ((mask & bit) != 0) {
            if (!world.isClient) user.sendMessage(Text.translatable("message.heroic.gem_already"), true);
            return TypedActionResult.fail(held);
        }
        if (!world.isClient) {
            chest.set(ModComponents.GEMS, mask | bit);
            if (!user.isCreative()) held.decrement(1);
            ServerWorld sw = (ServerWorld) world;
            sw.spawnParticles(ParticleTypes.END_ROD, user.getX(), user.getY() + 1.2, user.getZ(), 25, 0.3, 0.4, 0.3, 0.05);
            world.playSound(null, user.getBlockPos(), SoundEvents.BLOCK_BEACON_POWER_SELECT, SoundCategory.PLAYERS, 1.0f, 1.4f);
            user.sendMessage(Text.translatable("message.heroic.gem_socketed",
                    Text.translatable("gem.heroic." + Gems.NAMES[index])), true);
        }
        return TypedActionResult.success(held, world.isClient);
    }
}
