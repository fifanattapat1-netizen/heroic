package com.heroic.power;

import com.heroic.HeroUtil;
import com.heroic.entity.DroneEntity;
import com.heroic.HeroicMod;
import com.heroic.PlayerHeroState;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.LightningEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

public final class Powers {
    private Powers() {}

    public static void init() {
        reg("flight", new Flight());
        reg("super_speed", new SuperSpeed());
        reg("wall_run", new WallClimb());
        reg("invisibility", new Cloak());
        reg("fire_immunity", new FireImmunity());
        reg("lightning_strike", new LightningStrike());
        reg("shadow_step", new ShadowStep());
        reg("hardening", new Hardening());
        reg("ground_slam", new GroundSlam());
        reg("fire_blast", new FireBlast());
        reg("repulsor_blast", new RepulsorBlast());
        reg("drone_swarm", new DroneSwarm());
        reg("nano_shield", new NanoShield());
    }

    private static void reg(String name, Power p) {
        PowerRegistry.register(HeroicMod.id(name), p);
    }

    private static void burst(ServerPlayerEntity p, net.minecraft.particle.ParticleEffect fx, int n) {
        p.getServerWorld().spawnParticles(fx, p.getX(), p.getY() + 1.0, p.getZ(), n, 0.4, 0.6, 0.4, 0.05);
    }

    // ---------------- toggles ----------------

    static final class Flight extends Power {
        public boolean isToggle() { return true; }
        public float cost() { return 0.5f; }

        public void activate(ServerPlayerEntity p, PlayerHeroState st) {
            p.getAbilities().allowFlying = true;
            p.getAbilities().setFlySpeed(0.08f);
            p.sendAbilitiesUpdate();
            burst(p, ParticleTypes.CLOUD, 20);
        }

        public void tick(ServerPlayerEntity p, PlayerHeroState st) {
            if (!p.getAbilities().allowFlying) {
                p.getAbilities().allowFlying = true;
                p.sendAbilitiesUpdate();
            }
        }

        public void deactivate(ServerPlayerEntity p, PlayerHeroState st) {
            if (!p.isCreative() && !p.isSpectator()) {
                p.getAbilities().allowFlying = false;
                p.getAbilities().flying = false;
            }
            p.getAbilities().setFlySpeed(0.05f);
            p.sendAbilitiesUpdate();
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOW_FALLING, 100, 0, false, false, false));
        }
    }

    static final class SuperSpeed extends Power {
        private static final Identifier SPEED_ID = HeroicMod.id("super_speed");
        private static final Identifier STEP_ID = HeroicMod.id("super_speed_step");

        public boolean isToggle() { return true; }
        public float cost() { return 0.35f; }

        private void add(ServerPlayerEntity p, RegistryEntry<EntityAttribute> attr, Identifier id,
                         double v, EntityAttributeModifier.Operation op) {
            EntityAttributeInstance a = p.getAttributeInstance(attr);
            if (a != null && !a.hasModifier(id)) a.addTemporaryModifier(new EntityAttributeModifier(id, v, op));
        }

        private void remove(ServerPlayerEntity p, RegistryEntry<EntityAttribute> attr, Identifier id) {
            EntityAttributeInstance a = p.getAttributeInstance(attr);
            if (a != null) a.removeModifier(id);
        }

        public void activate(ServerPlayerEntity p, PlayerHeroState st) {
            add(p, EntityAttributes.GENERIC_MOVEMENT_SPEED, SPEED_ID, 1.2,
                    EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
            add(p, EntityAttributes.GENERIC_STEP_HEIGHT, STEP_ID, 0.6,
                    EntityAttributeModifier.Operation.ADD_VALUE);
            burst(p, ParticleTypes.CLOUD, 12);
        }

        public void deactivate(ServerPlayerEntity p, PlayerHeroState st) {
            remove(p, EntityAttributes.GENERIC_MOVEMENT_SPEED, SPEED_ID);
            remove(p, EntityAttributes.GENERIC_STEP_HEIGHT, STEP_ID);
        }
    }

    /** Sneak = hold position on the wall, otherwise climb. */
    static final class WallClimb extends Power {
        public boolean isToggle() { return true; }
        public float cost() { return 0.3f; }

        public void tick(ServerPlayerEntity p, PlayerHeroState st) {
            Vec3d look = p.getRotationVec(1.0f);
            Vec3d flat = new Vec3d(look.x, 0, look.z);
            if (flat.lengthSquared() < 1.0E-4) return;
            flat = flat.normalize();
            Vec3d start = p.getPos().add(0, 0.9, 0);
            Vec3d end = start.add(flat.multiply(0.8));
            BlockHitResult r = p.getWorld().raycast(new RaycastContext(start, end,
                    RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
            if (r.getType() == HitResult.Type.BLOCK && !p.isOnGround()) {
                Vec3d v = p.getVelocity();
                p.setVelocity(v.x, p.isSneaking() ? 0.0 : Math.max(v.y, 0.28), v.z);
                p.velocityModified = true;
                p.fallDistance = 0;
            }
        }
    }

    static final class Cloak extends Power {
        public boolean isToggle() { return true; }
        public float cost() { return 0.3f; }

        public void activate(ServerPlayerEntity p, PlayerHeroState st) {
            burst(p, ParticleTypes.SMOKE, 25);
        }

        public void tick(ServerPlayerEntity p, PlayerHeroState st) {
            if (p.age % 10 == 0 || !p.hasStatusEffect(StatusEffects.INVISIBILITY))
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.INVISIBILITY, 30, 0, false, false, false));
        }

        public void deactivate(ServerPlayerEntity p, PlayerHeroState st) {
            p.removeStatusEffect(StatusEffects.INVISIBILITY);
        }
    }

    static final class FireImmunity extends Power {
        public boolean isToggle() { return true; }
        public float cost() { return 0.15f; }

        public void tick(ServerPlayerEntity p, PlayerHeroState st) {
            if (p.age % 10 == 0 || !p.hasStatusEffect(StatusEffects.FIRE_RESISTANCE))
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 40, 0, false, false, false));
        }

        public void deactivate(ServerPlayerEntity p, PlayerHeroState st) {
            p.removeStatusEffect(StatusEffects.FIRE_RESISTANCE);
        }
    }

    // ---------------- instants ----------------

    static final class LightningStrike extends Power {
        public boolean isToggle() { return false; }
        public float cost() { return 35; }
        public int cooldown() { return 100; }

        public void activate(ServerPlayerEntity p, PlayerHeroState st) {
            Vec3d target = HeroUtil.traceBlocks(p, 48).getPos();
            LivingEntity e = HeroUtil.traceEntity(p, 48);
            if (e != null) target = e.getPos();
            ServerWorld w = p.getServerWorld();
            LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(w);
            if (bolt == null) return;
            bolt.refreshPositionAfterTeleport(target);
            bolt.setChanneler(p);
            w.spawnEntity(bolt);
        }
    }

    static final class ShadowStep extends Power {
        public boolean isToggle() { return false; }
        public float cost() { return 20; }
        public int cooldown() { return 40; }

        public void activate(ServerPlayerEntity p, PlayerHeroState st) {
            Vec3d dir = p.getRotationVec(1.0f);
            Vec3d last = p.getPos();
            for (double d = 0.5; d <= 10.0; d += 0.5) {
                Vec3d delta = dir.multiply(d);
                Box moved = p.getBoundingBox().offset(delta);
                if (!p.getWorld().isSpaceEmpty(p, moved)) break;
                last = p.getPos().add(delta);
            }
            burst(p, ParticleTypes.PORTAL, 30);
            p.requestTeleport(last.x, last.y, last.z);
            p.fallDistance = 0;
            burst(p, ParticleTypes.PORTAL, 30);
            HeroUtil.sound(p, SoundEvents.ENTITY_ENDERMAN_TELEPORT, 1.2f);
        }
    }

    static final class Hardening extends Power {
        public boolean isToggle() { return false; }
        public float cost() { return 40; }
        public int cooldown() { return 300; }

        public void activate(ServerPlayerEntity p, PlayerHeroState st) {
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 200, 2));
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 200, 0));
            burst(p, ParticleTypes.CRIT, 30);
            HeroUtil.sound(p, SoundEvents.BLOCK_ANVIL_PLACE, 1.0f);
        }
    }

    static final class GroundSlam extends Power {
        public boolean isToggle() { return false; }
        public float cost() { return 30; }
        public int cooldown() { return 120; }

        public void activate(ServerPlayerEntity p, PlayerHeroState st) {
            if (p.isOnGround()) {
                impact(p);
            } else {
                p.setVelocity(0, -2.0, 0);
                p.velocityModified = true;
                st.pendingSlam = true;
                st.slamTicks = 0;
            }
        }
    }

    public static void groundSlamImpact(ServerPlayerEntity p) {
        impact(p);
    }

    private static void impact(ServerPlayerEntity p) {
        p.fallDistance = 0;
        ServerWorld w = p.getServerWorld();
        Box area = p.getBoundingBox().expand(5.0, 2.0, 5.0);
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, area, en -> en != p && en.isAlive())) {
            Vec3d away = e.getPos().subtract(p.getPos());
            Vec3d push = new Vec3d(away.x, 0, away.z);
            push = push.lengthSquared() < 1.0E-4 ? Vec3d.ZERO : push.normalize().multiply(0.8);
            e.damage(p.getDamageSources().playerAttack(p), 6.0f);
            e.addVelocity(push.x, 0.5, push.z);
            e.velocityModified = true;
        }
        w.spawnParticles(ParticleTypes.EXPLOSION, p.getX(), p.getY() + 0.2, p.getZ(), 6, 1.5, 0.1, 1.5, 0.0);
        w.spawnParticles(ParticleTypes.CLOUD, p.getX(), p.getY() + 0.2, p.getZ(), 40, 2.0, 0.1, 2.0, 0.1);
        HeroUtil.sound(p, SoundEvents.BLOCK_ANVIL_LAND, 0.6f);
    }

    static final class FireBlast extends Power {
        public boolean isToggle() { return false; }
        public float cost() { return 15; }
        public int cooldown() { return 30; }

        public void activate(ServerPlayerEntity p, PlayerHeroState st) {
            ServerWorld w = p.getServerWorld();
            Vec3d start = p.getEyePos().add(0, -0.2, 0);
            Vec3d dir = p.getRotationVec(1.0f);
            LivingEntity target = HeroUtil.traceEntity(p, 14);
            double len = target != null ? start.distanceTo(target.getEyePos()) : 14;
            BlockHitResult bh = HeroUtil.traceBlocks(p, 14);
            if (target == null && bh.getType() != HitResult.Type.MISS) len = start.distanceTo(bh.getPos());
            for (double d = 1.0; d < len; d += 0.5) {
                Vec3d at = start.add(dir.multiply(d));
                w.spawnParticles(ParticleTypes.FLAME, at.x, at.y, at.z, 2, 0.05, 0.05, 0.05, 0.01);
            }
            if (target != null) {
                target.damage(p.getDamageSources().playerAttack(p), 5.0f);
                target.setOnFireFor(5);
            }
            HeroUtil.sound(p, SoundEvents.ENTITY_BLAZE_SHOOT, 1.0f);
        }
    }

    static final class RepulsorBlast extends Power {
        public boolean isToggle() { return false; }
        public float cost() { return 30; }
        public int cooldown() { return 60; }

        public void activate(ServerPlayerEntity p, PlayerHeroState st) {
            ServerWorld w = p.getServerWorld();
            Vec3d start = p.getEyePos().add(0, -0.2, 0);
            Vec3d dir = p.getRotationVec(1.0f);
            LivingEntity t = HeroUtil.traceEntity(p, 28);
            BlockHitResult bh = HeroUtil.traceBlocks(p, 28);
            Vec3d end = t != null ? t.getPos().add(0, t.getHeight() * 0.5, 0) : bh.getPos();
            double len = start.distanceTo(end);
            for (double d = 1.0; d < len; d += 0.4) {
                Vec3d at = start.add(dir.multiply(d));
                w.spawnParticles(ParticleTypes.END_ROD, at.x, at.y, at.z, 1, 0.02, 0.02, 0.02, 0.0);
                w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, at.x, at.y, at.z, 1, 0.05, 0.05, 0.05, 0.0);
            }
            w.spawnParticles(ParticleTypes.EXPLOSION, end.x, end.y, end.z, 1, 0, 0, 0, 0);
            Box area = new Box(end, end).expand(2.5);
            for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, area, en -> en != p && en.isAlive())) {
                e.damage(p.getDamageSources().playerAttack(p), e == t ? 9.0f : 5.0f);
            }
            HeroUtil.sound(p, SoundEvents.ENTITY_FIREWORK_ROCKET_BLAST, 0.8f);
        }
    }

    static final class DroneSwarm extends Power {
        public boolean isToggle() { return false; }
        public float cost() { return 40; }
        public int cooldown() { return 400; }

        public void activate(ServerPlayerEntity p, PlayerHeroState st) {
            if (DroneEntity.deploy(p, 3) > 0) HeroUtil.sound(p, SoundEvents.BLOCK_BEACON_ACTIVATE, 1.8f);
        }
    }

    /** Nanite barrier: constant resistance and regenerating absorption hearts while on. */
    static final class NanoShield extends Power {
        public boolean isToggle() { return true; }
        public float cost() { return 0.4f; }

        public void activate(ServerPlayerEntity p, PlayerHeroState st) {
            burst(p, ParticleTypes.ELECTRIC_SPARK, 30);
        }

        public void tick(ServerPlayerEntity p, PlayerHeroState st) {
            if (p.age % 20 == 0) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 40, 0, false, false, false));
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.ABSORPTION, 60, 1, false, false, false));
            }
        }
    }
}
