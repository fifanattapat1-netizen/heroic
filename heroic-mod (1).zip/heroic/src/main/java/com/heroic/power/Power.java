package com.heroic.power;

import com.heroic.PlayerHeroState;
import net.minecraft.server.network.ServerPlayerEntity;

/**
 * A power. TOGGLE powers drain cost() energy every tick while on.
 * INSTANT powers cost cost() once and then wait cooldown() ticks.
 */
public abstract class Power {
    public abstract boolean isToggle();

    public float cost() { return 0; }

    public int cooldown() { return 0; }

    public void activate(ServerPlayerEntity p, PlayerHeroState st) {}

    public void tick(ServerPlayerEntity p, PlayerHeroState st) {}

    public void deactivate(ServerPlayerEntity p, PlayerHeroState st) {}
}
