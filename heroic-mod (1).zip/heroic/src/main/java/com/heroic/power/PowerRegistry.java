package com.heroic.power;

import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Map;

/** Public API: other mods can register their own powers and reference them from hero JSON. */
public final class PowerRegistry {
    private static final Map<Identifier, Power> POWERS = new HashMap<>();

    private PowerRegistry() {}

    public static void register(Identifier id, Power power) {
        POWERS.put(id, power);
    }

    public static Power get(Identifier id) {
        return POWERS.get(id);
    }
}
