package com.heroic;

import com.heroic.entity.DroneEntity;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.command.CommandSource;
import net.minecraft.command.argument.IdentifierArgumentType;
import net.minecraft.item.Item;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

public final class ModCommands {
    private ModCommands() {}

    public static void init() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(CommandManager.literal("heroic")
                        .requires(src -> src.hasPermissionLevel(2))
                        .then(CommandManager.literal("suit")
                                .then(CommandManager.argument("hero", IdentifierArgumentType.identifier())
                                        .suggests((ctx, builder) -> {
                                            List<Identifier> ids = new ArrayList<>();
                                            for (HeroDefinition h : HeroManager.all()) ids.add(h.id());
                                            return CommandSource.suggestIdentifiers(ids, builder);
                                        })
                                        .executes(ctx -> {
                                            Identifier id = IdentifierArgumentType.getIdentifier(ctx, "hero");
                                            HeroDefinition hero = HeroManager.get(id);
                                            if (hero == null) {
                                                ctx.getSource().sendError(Text.literal("Unknown hero: " + id));
                                                return 0;
                                            }
                                            ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                                            for (Item piece : ModItems.SUIT_PIECES)
                                                p.getInventory().offerOrDrop(HeroSuitItem.stackFor(piece, hero));
                                            return 1;
                                        })))
                        .then(CommandManager.literal("drones")
                                .executes(ctx -> {
                                    ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                                    return DroneEntity.deploy(p, 3);
                                }))
                        .then(CommandManager.literal("city")
                                .executes(ctx -> city(ctx.getSource(), 5))
                                .then(CommandManager.argument("lots", IntegerArgumentType.integer(3, 7))
                                        .executes(ctx -> city(ctx.getSource(),
                                                IntegerArgumentType.getInteger(ctx, "lots")))))));
    }

    private static int city(ServerCommandSource src, int lots) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        if (CityBuilder.busy()) {
            src.sendError(Text.literal("A city is already being built."));
            return 0;
        }
        ServerPlayerEntity p = src.getPlayerOrThrow();
        CityBuilder.start(p, lots);
        src.sendFeedback(() -> Text.literal("Building a " + lots + "x" + lots
                + " city around you. Stay nearby; flat terrain works best."), true);
        return 1;
    }
}
