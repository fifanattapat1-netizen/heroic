package com.heroic.client;

import com.heroic.Gems;
import com.heroic.HeroDefinition;
import com.heroic.HeroManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public final class HeroHud {
    private HeroHud() {}

    public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden || mc.player == null || ClientHeroState.hero == null) return;
        HeroDefinition def = HeroManager.get(ClientHeroState.hero);
        if (def == null) return;

        int color = 0xFF000000 | def.color();
        int lines = def.powers().size();
        int info = ClientHeroState.gemInfo;
        int gemMask = info & 63;
        int extra = gemMask != 0 ? 24 : 0;
        int x = 8;
        int y = ctx.getScaledWindowHeight() - 40 - lines * 11 - extra;

        ctx.drawTextWithShadow(mc.textRenderer, Text.translatable(def.translationKey()), x, y, color);

        int barW = 90;
        float frac = ClientHeroState.maxEnergy <= 0 ? 0 : Math.min(1f, ClientHeroState.energy / ClientHeroState.maxEnergy);
        ctx.fill(x - 1, y + 11, x + barW + 1, y + 19, 0xAA000000);
        ctx.fill(x, y + 12, x + (int) (barW * frac), y + 18, color);

        for (int i = 0; i < lines; i++) {
            Identifier pid = def.powers().get(i);
            boolean active = (ClientHeroState.activeMask & (1 << i)) != 0;
            int cd = i < ClientHeroState.cooldowns.size() ? ClientHeroState.cooldowns.get(i) : 0;
            MutableText line = Text.literal("[").append(HeroicClient.key(i).getBoundKeyLocalizedText()).append("] ")
                    .append(Text.translatable("power." + pid.getNamespace() + "." + pid.getPath()));
            if (cd > 0) line.append(" " + (cd + 19) / 20 + "s");
            int c = active ? 0xFF55FF55 : (cd > 0 ? 0xFF888888 : 0xFFFFFFFF);
            ctx.drawTextWithShadow(mc.textRenderer, line, x, y + 22 + i * 11, c);
        }

        if (gemMask != 0) {
            int sel = (info >> 6) & 7;
            int cdSec = (info >> 9) & 255;
            int gy = y + 22 + lines * 11 + 3;
            for (int i = 0; i < Gems.COUNT; i++) {
                int gx = x + i * 12;
                boolean has = (gemMask >> i & 1) != 0;
                ctx.fill(gx - 1, gy - 1, gx + 9, gy + 9, (has && i == sel) ? 0xFFFFFFFF : 0xFF222222);
                ctx.fill(gx, gy, gx + 8, gy + 8, has ? (0xFF000000 | Gems.COLORS[i]) : 0xFF444444);
            }
            MutableText label = Text.translatable("gem.heroic." + Gems.NAMES[Math.min(sel, Gems.COUNT - 1)]);
            label.append(cdSec > 0 ? " " + cdSec + "s" : " [H]");
            ctx.drawTextWithShadow(mc.textRenderer, label, x, gy + 12,
                    cdSec > 0 ? 0xFF888888 : (0xFF000000 | Gems.COLORS[Math.min(sel, Gems.COUNT - 1)]));
            if (gemMask == Gems.ALL) {
                ctx.drawTextWithShadow(mc.textRenderer, Text.translatable("gem.heroic.snap_ready"),
                        x + 78, gy + 12, 0xFFFFD700);
            }
        }
    }
}
