package com.heroic.client;

import com.heroic.HeroUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;
import java.util.List;

/** AEGIS visor: scan frame + live list of hostile mobs with direction arrows. */
public final class AiHud {
    private static final String[] ARROWS = {"↑", "↗", "→", "↘", "↓", "↙", "←", "↖"};

    public static boolean overlay = true;
    private static List<Entry> threats = List.of();

    private record Entry(Text name, double dist, int arrow) {}

    private AiHud() {}

    public static boolean active(MinecraftClient mc) {
        return mc.player != null && HeroUtil.hasAi(mc.player, HeroUtil.wornHero(mc.player));
    }

    /** Called from the client tick (every 10 ticks). */
    public static void scan(MinecraftClient mc) {
        if (mc.world == null || mc.player == null || !active(mc)) {
            threats = List.of();
            return;
        }
        List<LivingEntity> found = mc.world.getEntitiesByClass(LivingEntity.class,
                mc.player.getBoundingBox().expand(32), e -> e instanceof Monster && e.isAlive());
        threats = found.stream()
                .sorted(Comparator.comparingDouble(e -> e.squaredDistanceTo(mc.player)))
                .limit(6)
                .map(e -> {
                    Vec3d d = e.getPos().subtract(mc.player.getPos());
                    double bearing = Math.toDegrees(Math.atan2(-d.x, d.z));
                    float rel = MathHelper.wrapDegrees((float) bearing - mc.player.getYaw());
                    int idx = Math.floorMod(Math.round(rel / 45f), 8);
                    return new Entry(e.getName(), e.distanceTo(mc.player), idx);
                })
                .toList();
    }

    public static void render(DrawContext ctx, RenderTickCounter tick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden || !overlay || !active(mc)) return;
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();

        // visor frame
        ctx.fill(0, 0, w, 2, 0x6600CCFF);
        ctx.fill(0, h - 2, w, h, 0x6600CCFF);

        int rows = Math.max(1, threats.size());
        int x = w - 150, y = 10;
        ctx.fill(x - 5, y - 4, w - 4, y + 34 + rows * 10, 0x66001828);
        ctx.drawTextWithShadow(mc.textRenderer, Text.translatable("aegis.hud.title"), x, y, 0xFF00D8FF);
        ctx.drawTextWithShadow(mc.textRenderer,
                Text.literal(String.format("XYZ %d %d %d  %s", mc.player.getBlockX(), mc.player.getBlockY(),
                        mc.player.getBlockZ(), mc.player.getHorizontalFacing().asString().toUpperCase())),
                x, y + 11, 0xFFAAAAAA);

        if (threats.isEmpty()) {
            ctx.drawTextWithShadow(mc.textRenderer, Text.translatable("aegis.hud.clear"), x, y + 24, 0xFF55FF55);
        } else {
            for (int i = 0; i < threats.size(); i++) {
                Entry e = threats.get(i);
                MutableText line = Text.literal(ARROWS[e.arrow()] + " ").append(e.name())
                        .append(" " + Math.round(e.dist()) + "m");
                ctx.drawTextWithShadow(mc.textRenderer, line, x, y + 24 + i * 10,
                        e.dist() < 8 ? 0xFFFF5555 : 0xFFFFAA00);
            }
        }
    }
}
