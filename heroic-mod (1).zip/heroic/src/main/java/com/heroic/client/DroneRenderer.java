package com.heroic.client;

import com.heroic.HeroicMod;
import com.heroic.entity.DroneEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

public class DroneRenderer extends MobEntityRenderer<DroneEntity, DroneModel> {
    private static final Identifier TEXTURE = HeroicMod.id("textures/entity/drone.png");

    public DroneRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new DroneModel(ctx.getPart(DroneModel.LAYER)), 0.3f);
    }

    @Override
    public Identifier getTexture(DroneEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(DroneEntity entity, MatrixStack matrices, float amount) {
        matrices.scale(1.4f, 1.4f, 1.4f);
    }
}
