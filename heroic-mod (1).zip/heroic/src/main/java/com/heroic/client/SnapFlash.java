package com.heroic.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

public final class SnapFlash {
    private static int ticks, max = 1;

    private SnapFlash() {}

    public static void trigger(int t) {
        ticks = t;
        max = Math.max(1, t);
    }

    public static void tick() {
        if (ticks > 0) ticks--;
    }

    public static void render(DrawContext ctx, RenderTickCounter counter) {
        if (ticks <= 0) return;
        float a = ticks / (float) max;
        int alpha = (int) (a * a * 255);
        ctx.fill(0, 0, ctx.getScaledWindowWidth(), ctx.getScaledWindowHeight(), (alpha << 24) | 0xFFFFFF);
    }
}
