package com.heroic.client;

import com.heroic.FabricatorBlock;
import com.heroic.HeroManager;
import com.heroic.ModEntities;
import com.heroic.ModItems;
import com.heroic.net.ActivatePowerPayload;
import com.heroic.net.AiCommandPayload;
import com.heroic.net.HeroListPayload;
import com.heroic.net.GemCommandPayload;
import com.heroic.net.HeroSyncPayload;
import com.heroic.net.SnapFlashPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.component.type.DyedColorComponent;
import net.minecraft.item.Item;
import org.lwjgl.glfw.GLFW;

public class HeroicClient implements ClientModInitializer {
    private static final KeyBinding[] KEYS = new KeyBinding[3];
    private static KeyBinding keyOverlay, keyDeploy, keyRecall, keyGemCycle, keyGemUse, keySnap, keyNano;

    public static KeyBinding key(int i) {
        return KEYS[i];
    }

    private static KeyBinding bind(String name, int key) {
        return KeyBindingHelper.registerKeyBinding(new KeyBinding(name, InputUtil.Type.KEYSYM, key, "category.heroic"));
    }

    @Override
    public void onInitializeClient() {
        int[] defaults = {GLFW.GLFW_KEY_Z, GLFW.GLFW_KEY_X, GLFW.GLFW_KEY_C};
        for (int i = 0; i < KEYS.length; i++) KEYS[i] = bind("key.heroic.power" + (i + 1), defaults[i]);
        keyOverlay = bind("key.heroic.ai_overlay", GLFW.GLFW_KEY_V);
        keyDeploy = bind("key.heroic.ai_deploy", GLFW.GLFW_KEY_B);
        keyRecall = bind("key.heroic.ai_recall", GLFW.GLFW_KEY_N);
        keyGemCycle = bind("key.heroic.gem_cycle", GLFW.GLFW_KEY_G);
        keyGemUse = bind("key.heroic.gem_use", GLFW.GLFW_KEY_H);
        keySnap = bind("key.heroic.snap", GLFW.GLFW_KEY_J);
        keyNano = bind("key.heroic.nano", GLFW.GLFW_KEY_K);

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.player == null) return;
            while (keyOverlay.wasPressed()) AiHud.overlay = !AiHud.overlay;
            boolean ai = AiHud.active(mc);
            while (keyDeploy.wasPressed()) if (ai) ClientPlayNetworking.send(new AiCommandPayload(0));
            while (keyRecall.wasPressed()) if (ai) ClientPlayNetworking.send(new AiCommandPayload(1));
            if (mc.player.age % 10 == 0) AiHud.scan(mc);
            SnapFlash.tick();
            while (keyNano.wasPressed()) ClientPlayNetworking.send(new GemCommandPayload(3));
            if (ClientHeroState.hero != null) {
                while (keyGemCycle.wasPressed()) ClientPlayNetworking.send(new GemCommandPayload(0));
                while (keyGemUse.wasPressed()) ClientPlayNetworking.send(new GemCommandPayload(1));
                while (keySnap.wasPressed()) ClientPlayNetworking.send(new GemCommandPayload(2));
            }
            if (ClientHeroState.hero == null) return;
            for (int i = 0; i < KEYS.length; i++) {
                while (KEYS[i].wasPressed()) ClientPlayNetworking.send(new ActivatePowerPayload(i));
            }
        });

        ClientPlayNetworking.registerGlobalReceiver(HeroSyncPayload.ID, (payload, ctx) -> ClientHeroState.update(payload));
        ClientPlayNetworking.registerGlobalReceiver(HeroListPayload.ID, (payload, ctx) -> HeroManager.setAll(payload.heroes()));
        ClientPlayNetworking.registerGlobalReceiver(SnapFlashPayload.ID, (payload, ctx) -> SnapFlash.trigger(payload.ticks()));
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> ClientHeroState.clear());

        ColorProviderRegistry.ITEM.register(
                (stack, tintIndex) -> tintIndex == 0 ? DyedColorComponent.getColor(stack, 0xFFFFFFFF) : 0xFFFFFFFF,
                ModItems.SUIT_PIECES.toArray(new Item[0]));

        EntityModelLayerRegistry.registerModelLayer(DroneModel.LAYER, DroneModel::getTexturedModelData);
        EntityRendererRegistry.register(ModEntities.DRONE, DroneRenderer::new);

        HudRenderCallback.EVENT.register(HeroHud::render);
        HudRenderCallback.EVENT.register(AiHud::render);
        HudRenderCallback.EVENT.register(SnapFlash::render);
        FabricatorBlock.openScreen = () -> MinecraftClient.getInstance().setScreen(new FabricatorScreen());
    }
}
