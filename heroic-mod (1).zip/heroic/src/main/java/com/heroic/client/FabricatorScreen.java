package com.heroic.client;

import com.heroic.Fabrication;
import com.heroic.HeroDefinition;
import com.heroic.HeroManager;
import com.heroic.net.FabricatePayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

public class FabricatorScreen extends Screen {
    public FabricatorScreen() {
        super(Text.translatable("screen.heroic.fabricator"));
    }

    @Override
    protected void init() {
        List<HeroDefinition> heroes = new ArrayList<>(HeroManager.all());
        int bw = 120, bh = 20, gap = 6, cols = 2;
        int startX = width / 2 - (cols * bw + gap) / 2;
        int startY = 52;
        for (int i = 0; i < heroes.size(); i++) {
            HeroDefinition h = heroes.get(i);
            MutableText tip = Text.empty();
            for (int k = 0; k < h.powers().size(); k++) {
                if (k > 0) tip.append(", ");
                Identifier pid = h.powers().get(k);
                tip.append(Text.translatable("power." + pid.getNamespace() + "." + pid.getPath()));
            }
            addDrawableChild(ButtonWidget.builder(
                            Text.translatable(h.translationKey()).styled(s -> s.withColor(h.color())),
                            b -> {
                                ClientPlayNetworking.send(new FabricatePayload(h.id()));
                                close();
                            })
                    .dimensions(startX + (i % cols) * (bw + gap), startY + (i / cols) * (bh + gap), bw, bh)
                    .tooltip(Tooltip.of(tip))
                    .build());
        }
        addDrawableChild(ButtonWidget.builder(ScreenTexts.DONE, b -> close())
                .dimensions(width / 2 - 50, height - 30, 100, 20).build());
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 20, 0xFFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer,
                Text.translatable("screen.heroic.cost", Fabrication.IRON, Fabrication.DIAMONDS, Fabrication.LEATHER),
                width / 2, 34, 0xAAAAAA);
    }
}
