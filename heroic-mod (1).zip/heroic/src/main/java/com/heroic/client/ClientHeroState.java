package com.heroic.client;

import com.heroic.net.HeroSyncPayload;
import net.minecraft.util.Identifier;

import java.util.List;

public final class ClientHeroState {
    public static Identifier hero;
    public static float energy;
    public static int maxEnergy;
    public static int activeMask;
    public static List<Integer> cooldowns = List.of();
    public static int gemInfo;

    private ClientHeroState() {}

    public static void update(HeroSyncPayload p) {
        hero = p.hero().equals(HeroSyncPayload.NONE) ? null : p.hero();
        energy = p.energy();
        maxEnergy = p.maxEnergy();
        activeMask = p.activeMask();
        cooldowns = p.cooldowns();
        gemInfo = p.gemInfo();
    }

    public static void clear() {
        hero = null;
        energy = 0;
        maxEnergy = 0;
        activeMask = 0;
        cooldowns = List.of();
        gemInfo = 0;
    }
}
