package com.heroic.client;

import com.heroic.HeroicMod;
import com.heroic.entity.DroneEntity;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.util.math.MatrixStack;

public class DroneModel extends EntityModel<DroneEntity> {
    public static final EntityModelLayer LAYER = new EntityModelLayer(HeroicMod.id("drone"), "main");

    private final ModelPart root;
    private final ModelPart[] rotors = new ModelPart[4];

    public DroneModel(ModelPart root) {
        this.root = root;
        for (int i = 0; i < 4; i++) rotors[i] = root.getChild("rotor" + i);
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData data = new ModelData();
        ModelPartData r = data.getRoot();
        r.addChild("body", ModelPartBuilder.create().uv(0, 0).cuboid(-4f, -4f, -4f, 8f, 4f, 8f),
                ModelTransform.pivot(0f, 22f, 0f));
        r.addChild("eye", ModelPartBuilder.create().uv(0, 16).cuboid(-1.5f, -3f, -4.5f, 3f, 2f, 1f),
                ModelTransform.pivot(0f, 22f, 0f));
        float[][] pos = {{-5, -5}, {5, -5}, {-5, 5}, {5, 5}};
        for (int i = 0; i < 4; i++) {
            r.addChild("rotor" + i, ModelPartBuilder.create().uv(0, 24).cuboid(-3f, -0.5f, -0.5f, 6f, 1f, 1f),
                    ModelTransform.pivot(pos[i][0], 17.5f, pos[i][1]));
        }
        return TexturedModelData.of(data, 64, 32);
    }

    @Override
    public void setAngles(DroneEntity e, float limbSwing, float limbSwingAmount, float age, float headYaw, float headPitch) {
        for (int i = 0; i < 4; i++) rotors[i].yaw = age * (i % 2 == 0 ? 1.8f : -1.8f);
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumer vertices, int light, int overlay, int color) {
        root.render(matrices, vertices, light, overlay, color);
    }
}
